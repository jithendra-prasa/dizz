# DizzItUp

## Paybills backend

## Description

This is the repo for DizzItUp pay bills backend

## Table of Contents

- [Docs](#docs)
- [Dev Requirements](#dev-requirements)
- [Dev Environment Setup](#dev-environment-setup)
- [How to contribute](#how-to-contribute)
- [technologies ](#technologies)
- [Tests](#tests)
- [License](#license)

## Docs
You can view the documentation [here](https://everlasting-mass-661.notion.site/API-Documentation-8c2e4a1379e7479395ee8cd89c81ccf7?pvs=4)

## Dev Requirements

Git/GitBash, VS Code, NodeJS, and the source code, of course! 🛠️

## Dev Environment Setup

Please make sure you have NodeJS downloaded
To get the development environment running:

1. Clone this repo
2. Navigate to the repo on your local machine
3. Run `npm i` and this will install all the depencencys needed
4. Rename `.envEXAMPLE` to `.env` and enter your api keys
5. run `npm run dev` to run!
6. you can use postman or boomerang to test this is working, you can send a get or post request to the following endpoints (more precise endponts may need to be added, these are mostly just to verify everything is working)`http://localhost:4400/payments/airtime`, `http://localhost:4400/payments/giftCard`, `http://localhost:4400/payments/utility`

- `src/`: Contains all javaScript code to allow this app to function
- `src/server.js`: Contains the js code to initialize and run the app

- `src/routes`: Defines all the HTTP routes
- `src/controllers`: This is where the business logic goes
- `src/services`: This is where we retrieve & send data from (to and from reloadly&shopifyAPIS, and our DB)
- `src/middleware`: This is where middleware goes (dont worry about this for now)

- `src/utils`:

## How to contribute

1. Clone the repository
2. Create a branch for your bug fix or feature
3. Make necessary changes and commit those changes
4. Push changes to GitHub
5. Create a pull request to this repo to submit your changes for review

## Technologies

- **JavaScript**
- **NodeJS**
- **ExpressJS**
- **ReloadlyAPI**
- **ShopifyAPI**

## Tests

- There are no tests added yet

---

## Licence

MIT License

Copyright (c) 2024 DizzItUp

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
