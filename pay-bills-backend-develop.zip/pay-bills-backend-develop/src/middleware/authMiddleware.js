export const authMiddleware = {
  isAuthenticated: async (req, res, next) => {
    if (!req.isAuthenticated())
      return res.status(401).json({ error: "Not logged in" });

    return next();
  },
};
