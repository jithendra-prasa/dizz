import {
  getCountry,
  getCountryByAbbreviation,
  getCurrency,
} from "country-currency-map-2";

const getIpInfoMiddleware = (req, res, next) => {
  const countryAbb = req.ipInfo.country === "GB" ? "UK" : req.ipInfo.country;
  const countryFullName = getCountryByAbbreviation(countryAbb);

  const countryData = getCountry(countryFullName);

  const localisationDetails = {
    country: {
      abb: countryAbb,
      name: countryFullName,
    },
    currency: {
      abb: countryData.currency,
      symbol: getCurrency(countryData.currency).symbolFormat,
      name: getCurrency(countryData.currency).name,
    },
  };
  req.localisation = localisationDetails;
  next();
};

export const localisationMiddleware = [getIpInfoMiddleware];
