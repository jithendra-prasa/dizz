import express from "express";
import cors from "cors";
import "dotenv/config";
import { getIpInfo } from "../utils/ipInfo.js";

const jsonMiddleware = express.json();

const authorizedIps = process.env.AUTHORIZED_IPS || "";

const whitelist = [
  process.env.FRONTEND_URL,
  ...authorizedIps.split(",")
]

console.log("CORS", { whitelist });

const corsMiddleware = cors({
  // origin: process.env.FRONTEND_URL,
  origin: (origin, callback) => {
    // Authorize request with no origin (e.g., Postman, server-to-server requests)
    if (!origin) {
      return callback(null, true);
    }

    if (whitelist.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`The unknown origin :${origin} is not allowed by CORS policy`));
    }
  },
  methods: "GET,POST,PUT,DELETE",
  credentials: true,
});

// Custom error handling middleware
const jsonErrorHandler = (err, req, res, next) => {
  if (err instanceof SyntaxError && "body" in err && err.status === 400) {
    res.status(400).json({ error: "Invalid request" });
  } else {
    next(err);
  }
};

const getIpInfoMiddleware = function (req, res, next) {
  var ip = req.get("x-real-ip") || "127.0.0.1";
  req.ipInfo = { ip, ...getIpInfo(ip) };
  next();
};

// Conditional JSON middleware
const conditionalJsonMiddleware = (req, res, next) => {
  if (req.path === "/payments/stripe/webhook") {
    return next();
  }
  return jsonMiddleware(req, res, next);
};

export const essentialMiddleware = [
  getIpInfoMiddleware,
  conditionalJsonMiddleware,
  corsMiddleware,
  jsonErrorHandler,
];
