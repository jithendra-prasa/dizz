import logger from "../utils/logger.js";

// Request logging middleware
const requestLoggingMiddleware = (req, res, next) => {
  //  console.log(JSON.stringify(req.headers));
  const reqData = {
    method: req.method,
    url: req.url,
    ip: req.ipInfo.ip,
    body: req.body || {}, // Ensure body is parsed by earlier middleware
    country: req.localisation.country ? req.localisation.country.name : "N/A",
    user: req.user || "Anonymous",
    params: req.params,
  };

  // Capture response data by overriding res.json
  const originalJson = res.json;
  res.json = function (body) {
    res.body = body; // Capture the response body
    return originalJson.apply(this, arguments); // Call original res.json
  };

  res.on("finish", () => {
    const resData = {
      statusCode: res.statusCode,
      body:
        res.body && JSON.stringify(res.body).length < 3001
          ? res.body
          : "Body too big", // Log the response body
    };

    logger.info(JSON.stringify({ reqData, resData }));
  });

  next();
};

// Error logging middleware
const errorLoggingMiddleware = (err, req, res, next) => {
  logger.error(err.message, JSON.stringify(err));
  next();
};

// Export the essential middleware as an array
export const loggingMiddleware = [
  requestLoggingMiddleware,
  errorLoggingMiddleware,
];
