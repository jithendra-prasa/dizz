import passport from "passport";
import { Strategy } from "passport-local";
import { prisma } from "../server.js";

export default passport.use(
  new Strategy({ usernameField: "email" }, async (username, password, done) => {
    try {
      const findUser = await prisma.user.findUnique({
        //TODO replace this with user service
        where: {
          email: username,
        },
      });
      if (!findUser)
        return done(null, false, { message: "Invalid Creadentials" });
      if (findUser.isGuest)
        return done(null, false, {
          message: "This email is a guest only, Please signup to log in",
        });
      if (findUser.password !== password)
        return done(null, false, { message: "Invalid Creadentials" });

      done(null, findUser);
    } catch (e) {
      done(e, false);
    }
  })
);

passport.serializeUser((user, done) => {
  // console.log("inside steralize user")
  // console.log(user)
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  // console.log("Inside deserialize user")
  // console.log(id)
  try {
    const findUser = await prisma.user.findUnique({
      //TODO replace this with user service
      where: {
        id,
      },
      //   include: {
      //     modules: true,
      //   },
    });
    if (!findUser) throw new Error("User not found");
    done(null, findUser);
  } catch (e) {
    done(e, null);
  }
});
