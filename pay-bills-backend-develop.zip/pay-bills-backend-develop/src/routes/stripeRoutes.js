import express from "express";
import { StripeController } from "../controllers/stripeController.js";

export const stripeRoutes = express.Router();

stripeRoutes.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  StripeController.HandelWebHook
);
