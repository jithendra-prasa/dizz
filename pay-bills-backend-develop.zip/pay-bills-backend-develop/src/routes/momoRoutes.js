// Mobile Money (MoMo) routes

import express from "express";
import { MomoController } from "../controllers/momoController.js";

export const momoRoutes = express.Router();

momoRoutes.get("/supportedCountries", MomoController.getSupportedCountries);
// momoRoutes.post("/supportedOperatorsByCountry", MomoController.getLocationDataByCountryCode);