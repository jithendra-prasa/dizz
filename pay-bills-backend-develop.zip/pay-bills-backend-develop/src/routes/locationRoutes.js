import express from "express";
import { LocationController } from "../controllers/locationController.js";

export const locationRoutes = express.Router();

locationRoutes.get("/data", LocationController.getLocationData);
locationRoutes.post("/dataByCountryCode", LocationController.getLocationDataByCountryCode);