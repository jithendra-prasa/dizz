// @ts-check

import express from "express";
import { NowPaymentsController } from "../controllers/nowPaymentsController.js";

export const nowPaymentsRoutes = express.Router();

nowPaymentsRoutes.post(
    "/webhook",
    //   express.raw({ type: "application/json" }),
    NowPaymentsController.handleWebhook
);
