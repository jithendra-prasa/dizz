import express from "express";
import { GiftCardController } from "../controllers/giftCardController.js";

export const giftCardsRoutes = express.Router();

giftCardsRoutes.get("/", GiftCardController.placeholder);
giftCardsRoutes.post("/", GiftCardController.placeholder);

giftCardsRoutes.get(
  "/cards/country/:country",
  GiftCardController.GetCardsByCountry
);

giftCardsRoutes.post("/pay", GiftCardController.Pay);
giftCardsRoutes.post("/payAsGuest", GiftCardController.PayAsGuest);
