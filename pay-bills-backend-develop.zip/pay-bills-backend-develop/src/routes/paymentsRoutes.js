//@ts-check

import express from "express";
import { airtimeRoutes } from "./airtimeRoutes.js";
import { giftCardsRoutes } from "./giftCardRoutes.js";
import { utilityRoutes } from "./utilityRoutes.js";
import { stripeRoutes } from "./stripeRoutes.js";
import { nowPaymentsRoutes } from "./nowPaymentsRoutes.js";
import { pawaPayRoutes } from "./pawaPayRoutes.js";

export const paymentsRoutes = express.Router();

paymentsRoutes.use("/stripe", stripeRoutes);
paymentsRoutes.use("/nowPayments", nowPaymentsRoutes);
paymentsRoutes.use("/pawaPay", pawaPayRoutes);

paymentsRoutes.use("/airtime", airtimeRoutes);
paymentsRoutes.use("/giftCard", giftCardsRoutes);
paymentsRoutes.use("/utility", utilityRoutes);
