// @ts-check
// Amount and fees calculation routes

import express from "express";
import { AmountFeesController } from "../controllers/amountFeesController.js";

export const calculationRoutes = express.Router();

// TODO: Change to get. Frontend too
calculationRoutes.post("/amountAndFees", AmountFeesController.calculateAmountAndFees);