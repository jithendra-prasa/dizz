import express from "express";
import { AuthController } from "../controllers/authController.js";
import passport from "passport";
import { authMiddleware } from "../middleware/authMiddleware.js";

export const authRoutes = express.Router();

authRoutes.post("/login", passport.authenticate("local"), AuthController.Login);
authRoutes.post("/signup", AuthController.Signup);
authRoutes.post("/logout", AuthController.Logout);
authRoutes.get(
  "/status",
  authMiddleware.isAuthenticated,
  AuthController.getStatus
);
