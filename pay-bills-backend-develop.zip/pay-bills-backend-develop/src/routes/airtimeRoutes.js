import express from "express";
import { AirtimeController } from "../controllers/airtimeController.js";

export const airtimeRoutes = express.Router();

airtimeRoutes.get("/", AirtimeController.placeholder);
airtimeRoutes.post("/", AirtimeController.placeholder);

// airtimeRoutes.get("/countries", AirtimeController.Countries);
airtimeRoutes.get("/operators", AirtimeController.Operators);
airtimeRoutes.get(
  "/operators/country/:country",
  AirtimeController.GetOperatorByCountry
);
airtimeRoutes.get(
  "/operators/autodetect",
  AirtimeController.AutoDetectOperator
);
airtimeRoutes.get("/operators/:operatorId", AirtimeController.GetOperatorById);
airtimeRoutes.post("/pay", AirtimeController.Pay);
airtimeRoutes.post("/payAsGuest", AirtimeController.PayAsGuest);
airtimeRoutes.get("/airtimetransaction", AirtimeController.GetTransactionInfo);
