import express from "express";
import { OrderSummaryController } from "../controllers/orderSummaryController.js";

export const orderSummaryRoutes = express.Router();

orderSummaryRoutes.post("/save", OrderSummaryController.createOrderSummary);
orderSummaryRoutes.get("/getAll", OrderSummaryController.getAll);