// @ts-check

import express from "express";
import { PawaPayController } from "../controllers/pawaPayController.js";

export const pawaPayRoutes = express.Router();

pawaPayRoutes.post(
    "/webhook",
    //   express.raw({ type: "application/json" }),
    PawaPayController.handleWebhook
);
