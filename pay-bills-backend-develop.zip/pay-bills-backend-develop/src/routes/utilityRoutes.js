import express from "express";
import { UtilityController } from "../controllers/utilityController.js";

export const utilityRoutes = express.Router();

utilityRoutes.get("/", UtilityController.placeholder);
utilityRoutes.post("/", UtilityController.placeholder);

utilityRoutes.get("/billers", UtilityController.Billers);
utilityRoutes.get(
  "/billers/country/:country",
  UtilityController.GetBillersByCountry
);

utilityRoutes.post("/pay", UtilityController.Pay);
utilityRoutes.post("/payAsGuest", UtilityController.PayAsGuest);

utilityRoutes.get("/transactions", UtilityController.TransactionsForThisUser);
