// @ts-check

import { z } from 'zod';

const MetadataSchema = z.object({
    fieldName: z.string(),
    fieldValue: z.string(),
    isPII: z.boolean().optional()
});

export const PaymentPageRequestSchema = z.object({
    depositId: z.string({
        message: "depositId is required"
    }).uuid({
        message: "depositId must be a valid UUID"
    }),
    returnUrl: z.string({
        message: "returnUrl is required"
    }).url({
        message: "returnUrl must be a valid URL"
    }),
    amount: z.string({
        required_error: "amount is required"
    }),
    country: z.string({
        required_error: "country is required"
    }).length(3),
    metadata: z.array(MetadataSchema, {
        required_error: "metadata is required"
    }),

    language: z.enum(["EN", "FR"]).default("EN"),
    msisdn: z.string().optional(),
    statementDescription: z.string().min(4).max(22).optional(),
    reason: z.string().min(1).max(50).optional(),
}, { required_error: "The payment page request object data is required", });


// Address schema
const AddressSchema = z.object({
    value: z.string(),
});

// Payer schema
const PayerSchema = z.object({
    type: z.enum(["MSISDN"]),
    address: AddressSchema,
});

// SuspiciousActivity schema
const SuspiciousActivitySchema = z.object({
    activityType: z.enum(["AMOUNT_DISCREPANCY"]),
    comment: z.string(),
});

// FailureReason schema
const FailureReasonSchema = z.object({
    failureCode: z.enum([
        "PAYER_NOT_FOUND", "PAYMENT_NOT_APPROVED",
        "PAYER_LIMIT_REACHED", "INSUFFICIENT_BALANCE",
        "TRANSACTION_ALREADY_IN_PROCESS", "OTHER_ERROR"
    ]),
    failureMessage: z.string().nullable(),
});

// Metadata schema
const DepositMetadataSchema = z.union([
    z.object({ orderId: z.string() }),
    z.record(z.string())
]);

// Main deposit schema
export const PawaPayDepositSchema = z.object({
    depositId: z.string(),
    status: z.enum(["COMPLETED", "FAILED"]),
    requestedAmount: z.string(),
    currency: z.string(),
    country: z.string(),
    correspondent: z.string(),
    payer: PayerSchema,
    customerTimestamp: z.string().datetime(),
    created: z.string().datetime(),
    statementDescription: z.string().nullable(),
    depositedAmount: z.string().nullable(),
    respondedByPayer: z.string().datetime().nullable(),
    correspondentIds: z.record(z.string()).nullable(),
    suspiciousActivityReport: z.array(SuspiciousActivitySchema).nullable(),
    failureReason: FailureReasonSchema.nullable(),
    metadata: DepositMetadataSchema.nullable(),
});


export const PawaPayPublicKeysSchema = z.array(
    z.object({
        id: z.string(),
        key: z.string(),
    })
);
