//@ts-check

import { z } from 'zod';

/**
 * `NOWPayments` invoice schema
 */
export const NPInvoiceSchema = z.object({
    price_amount: z.number({
        required_error: "price_amount is required"
    }),
    price_currency: z.string({
        required_error: "price_currency is required"
    }),
    order_id: z.string({
        required_error: "order_id is required"
    }),
    order_description: z.string({
        required_error: "order_description is required"
    }).optional(),
    // is_fee_paid_by_user: z.boolean()
}, { required_error: "The invoice object data is required", });

const FeeSchema = z.object({
    currency: z.string(),
    depositFee: z.number(),
    withdrawalFee: z.number(),
    serviceFee: z.number()
});

/**
 * `NOWPayments` webhook response schema
 */
export const NPWebhookResponseSchema = z.object({
    payment_id: z.number(),
    parent_payment_id: z.number(),
    payment_status: z.enum(["waiting", "confirming", "confirmed", "sending", "partially_paid", "finished", "failed", "refunded", "expired"]),
    price_amount: z.number(),
    price_currency: z.string(),
    order_id: z.string().optional(),
    order_description: z.string().optional(),
    fee: FeeSchema,

    invoice_id: z.string().optional(),
    pay_address: z.string(),
    payin_extra_id: z.string().optional(),
    pay_amount: z.number(),
    actually_paid: z.number(),
    actually_paid_at_fiat: z.number(),
    pay_currency: z.string(),
    purchase_id: z.string(),
    outcome_amount: z.number(),
    outcome_currency: z.string(),
    payment_extra_ids: z.string().optional(),
});
