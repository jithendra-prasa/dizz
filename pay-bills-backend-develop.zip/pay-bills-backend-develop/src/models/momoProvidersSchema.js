//@ts-check

import { z } from "zod";

const OperatorSchema = z.object({
    name: z.string().nonempty({ message: "Operator name is required" }),
    momoName: z.string().nonempty({ message: "Operator momoName is required" }),
    percentageFee: z.number().nullable(), // Nullable fields do not require a custom message
    status: z.boolean({ required_error: "Operator status is required" }),
});

const CountrySchema = z.object({
    countryIso2: z
        .string()
        .nonempty({ message: "Country ISO2 code is required" }),
    countryIso3: z
        .string()
        .nonempty({ message: "Country ISO3 code is required" }),
    operators: z
        .array(OperatorSchema, { required_error: "Operators array is required" })
        .nonempty({ message: "Operators array cannot be empty" }),
});

const MomoProviderSchema = z.object({
    name: z.string().nonempty({ message: "Provider name is required" }),
    status: z.boolean({ required_error: "Provider status is required" }).default(true),
    countries: z
        .array(CountrySchema, { required_error: "Countries array is required" })
        .nonempty({ message: "Countries array cannot be empty" }),
});

export const MomoProvidersSchema = z
    .array(MomoProviderSchema, { required_error: "Providers array is required" })
    .nonempty({ message: "Providers array cannot be empty" });

