//@ts-check

import logger from "../utils/logger.js";
import { z } from 'zod';
import { PawaPayDepositSchema } from '../models/pawaPaySchema.js';
import { processPawaPayDepositEvent } from '../services/pawaPay/webhookService.js';

export const PawaPayController = {
    handleWebhook: async (req, res) => {
        try {
            const requestHeaders = req.headers;

            /** @type {z.infer<typeof PawaPayDepositSchema>} */
            const requestBody = req.body;

            // console.log("PawaPay callback request headers", requestHeaders);
            // console.log("PawaPay callback request body", requestBody);
            // console.log({ requestHeaders });


            // const contentValidity = validateContentIntegrity(requestBody, requestHeaders["content-digest"]);

            // console.log({ contentValidity });

            // const pawaPayPublicKeys = await getPawaPayPublicKeys()

            // const signatureValidity = validateSignature(req, pawaPayPublicKeys[0].key);

            // console.log({ signatureValidity });


            // * Process webhook request (payment failed, finished, expired, etc.)
            await processPawaPayDepositEvent(requestBody);

            res.send();
        } catch (e) {
            logger.error("[PawaPayController.handleWebhook] \n" + (e));

            res.status(500).json({ error: "Internal server error" });
        }
    },


}
