// @ts-check

import Decimal from "decimal.js";
import { CARD, CRYPTO, MOBILE_MONEY } from "../constants/paymentMethodConstants.js";
import { convertAmountCurrency } from "../services/currencies/converter.js";
import { ordersDatabaseService } from "../services/database/orders.js";
import { userService } from "../services/database/userService.js";
import { calculateAmountWithFees } from "../services/fees/amountCalculator.js";
import { reloadlyUtilityService } from "../services/reloadly/utilityService.js";
import { StripeUtilityService } from "../services/stripe/utilityService.js";
import { CreateQueryString } from "../utils/api.js";
import {
  ConvertUtilitySupplierBYIDCurrency,
  ConvertUtilitySuppliersCurrencys,
  GetCurrentExhnageRate,
  convertCurrency,
} from "../utils/convertCurrency.js";
import logger from "../utils/logger.js";
import { convertAmountToNPCurrency, createInvoice } from "../services/nowPayments/cryptoService.js";
import { DEFAULT_DECIMAL_PLACES } from "../constants/decimalConstants.js";
import { v4 as uuidv4 } from 'uuid';
import { getSupportedMoMoOperatorsByCountry } from "../services/mobileMoney/momoService.js";
import { requestPawaPayPaymentPage } from "../services/pawaPay/mobileMoneyService.js";

export const UtilityController = {
  placeholder: async (req, res) => {
    console.log("hit");
    try {
      const serviceResponce = await reloadlyUtilityService.placeholder();
      res.json(serviceResponce);
    } catch (e) {
      logger.error("[UtilityCotroller] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  Billers: async (req, res) => {
    try {
      const reloadlyApiQuery = CreateQueryString(req.query);
      console.log(reloadlyApiQuery);

      const reloadlyResponce = await reloadlyUtilityService.GetBillers(
        reloadlyApiQuery
      );
      res.json(reloadlyResponce);
    } catch (e) {
      logger.error("[UtilityCotroller.Billers] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  GetBillersByCountry: async (req, res) => {
    const { country } = req.params;
    try {
      const reloadlyResponce = await reloadlyUtilityService.GetBillersByCountry(
        country
      );

      const resloadlyResponceWithConvertedCurrencys =
        await ConvertUtilitySuppliersCurrencys(
          reloadlyResponce.content,
          req.localisation.currency.abb
        );

      res.json({
        ...reloadlyResponce,
        content: resloadlyResponceWithConvertedCurrencys,
      });
    } catch (e) {
      logger.error(
        "[UtilityCotroller.GetBillersByCountry] " + JSON.stringify(e)
      );
      res.status(500).json({ error: "Internal server error" });
    }
  },

  Pay: async (req, res) => {
    try {
      console.log(req.body);
      const { subscriberAccountNumber, amount, billerId, referenceId, userID, paymentMethod } =
        req.body; //amount is ammount in benafisharys country

      // Check if required fields are present
      if (!subscriberAccountNumber || !amount || !billerId || !userID || !paymentMethod) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        subscriberAccountNumber,
        amount,
        billerId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      // Conditionally add referenceId if it is defined
      if (referenceId !== undefined) {
        fields.referenceId = referenceId;
      }

      const billerDetails = await reloadlyUtilityService.getBillerByID(
        billerId
      );

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const billerDetailsWithConvertedCurrenys =
        await ConvertUtilitySupplierBYIDCurrency(
          billerDetails,
          userCurrencyCode
        );

      // const currentExhnageRateForBenToUserCurrencyPair =
      //   await GetCurrentExhnageRate(
      //     billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
      //     userCurrencyCode
      //   );

      const currentExhnageRateForBenToOurCurrencyPair =
        await GetCurrentExhnageRate(
          billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
          billerDetailsWithConvertedCurrenys.internationalTransactionCurrencyCode
        );

      // const currentExhnageRateForOurCurrencyToUsers =
      //   await GetCurrentExhnageRate(
      //     billerDetailsWithConvertedCurrenys.internationalTransactionCurrencyCode,
      //     userCurrencyCode
      //   );

      // const amountInUserC = parseFloat(
      //   convertCurrency(amount, currentExhnageRateForBenToUserCurrencyPair)
      // );

      // const UtilityBillFixedFeeInUserCurrency = parseFloat(
      //   convertCurrency(0.75, currentExhnageRateForOurCurrencyToUsers)
      // ); //todo pull these values form a table in mysql
      // const UtilityBillFeePersentage = 20;

      // const amountInUserCWithOurFees =
      //   amountInUserC +
      //   (amountInUserC * (UtilityBillFeePersentage / 100) +
      //     UtilityBillFixedFeeInUserCurrency);

      const amountInOurC = parseFloat(
        convertCurrency(amount, currentExhnageRateForBenToOurCurrencyPair)
      );

      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(
        amountInOurC,
        billerDetails.internationalTransactionCurrencyCode,
        userCountryIsoCode
      );
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });

      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES
      // TODO: Should use local amount instead of international ?

      // Checking for minimun amount
      const billMinAmount = billerDetails.minLocalTransactionAmount;
      if (billMinAmount && amount < billMinAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current minimum amount for this bill is ${billMinAmount} ${billerDetails.localTransactionFeeCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      const billMaxAmount = billerDetails.maxLocalTransactionAmount;
      if (billMaxAmount && amount > billMaxAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current maximum amount for this bill is ${billMaxAmount} ${billerDetails.localTransactionFeeCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      // Getting user by id
      const user = await userService.GetUser(userID);

      // Checking if user exists
      if (!user) {
        return res.status(404).json({ error: "No user found for that Id", errorCode: "USER_NOT_FOUND" });
      }

      // Extracting user email
      const { email } = user;

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        userID,
        "Pay Utility",
        [
          {
            name: `${billerDetailsWithConvertedCurrenys.name} - ${billerDetailsWithConvertedCurrenys.simpleType}`,
            quantity: 1, // need to separate the fee and ammount
            ammountWithFeesInOurC:
              billerDetailsWithConvertedCurrenys.senderFreeOurC + amountWithOurFeesData.baseAmount,
            ammountWithFeesInUsersC:
              billerDetailsWithConvertedCurrenys.senderFeeUserC +
              amountWithOurFeesInUserC.convertedAmount,
            ReloadlyFeesInOurC:
              billerDetailsWithConvertedCurrenys.senderFreeOurC,
            ReloadlyFeesInUserC:
              billerDetailsWithConvertedCurrenys.senderFeeUserC,
            AmmountWithoutFeesInOurC: amountWithOurFeesData.baseAmount,
            AmmountWithoutFeesInUserC: amountWithOurFeesInUserC.convertedAmount,
            subscriberAccountNumber,
            billerId,
            referenceId,
            ammountInBenCurrency: amount,
            benCurrencyCode:
              billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
            userCurrencyCode: userCurrencyCode,
          },
        ],
        // "Remove COl",
        amountWithOurFeesData.finalAmountCurrency,
        billerDetailsWithConvertedCurrenys.senderFreeOurC +
        amountWithOurFeesData.finalAmount //+ ourFee    <- This is the grand total
      );

      let redirectUrl;

      if (paymentMethod === CARD) {
        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            billerDetailsWithConvertedCurrenys.name,
            billerDetailsWithConvertedCurrenys.simpleType,
            userCurrencyCode,
            billerDetailsWithConvertedCurrenys.senderFreeOurC,
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(billerDetailsWithConvertedCurrenys.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(billerDetailsWithConvertedCurrenys.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      logger.error("[UtilityCotroller.Pay] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  PayAsGuest: async (req, res) => {
    try {
      console.log(req.body);
      const {
        subscriberAccountNumber,
        amount,
        billerId,
        referenceId,
        firstName,
        surname,
        email,
        paymentMethod
      } = req.body;

      // Check if required fields are present
      if (
        !subscriberAccountNumber ||
        !amount ||
        !billerId ||
        !firstName ||
        !surname ||
        !email ||
        !paymentMethod
      ) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        subscriberAccountNumber,
        amount,
        billerId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      // Conditionally add referenceId if it is defined
      if (referenceId !== undefined) {
        fields.referenceId = referenceId;
      }

      const user =
        (await userService.getUserByEmail(email)) ||
        (await userService.createGuestUser(firstName, surname, email));

      if (!user.isGuest) {
        return res.status(401).json({ error: "This email is already in use" });
      }

      const billerDetails = await reloadlyUtilityService.getBillerByID(
        billerId
      );

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const billerDetailsWithConvertedCurrenys =
        await ConvertUtilitySupplierBYIDCurrency(
          billerDetails,
          userCurrencyCode
        );

      // const currentExhnageRateForBenToUserCurrencyPair =
      //   await GetCurrentExhnageRate(
      //     billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
      //     userCurrencyCode
      //   );

      const currentExhnageRateForBenToOurCurrencyPair =
        await GetCurrentExhnageRate(
          billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
          billerDetailsWithConvertedCurrenys.internationalTransactionCurrencyCode
        );

      // const currentExhnageRateForOurCurrencyToUsers =
      //   await GetCurrentExhnageRate(
      //     billerDetailsWithConvertedCurrenys.internationalTransactionCurrencyCode,
      //     userCurrencyCode
      //   );

      // const amountInUserC = parseFloat(
      //   convertCurrency(amount, currentExhnageRateForBenToUserCurrencyPair)
      // );

      // const UtilityBillFixedFeeInUserCurrency = parseFloat(
      //   convertCurrency(0.75, currentExhnageRateForOurCurrencyToUsers)
      // ); //todo pull these values form a table in mysql
      // const UtilityBillFeePersentage = 20;

      // const amountInUserCWithOurFees =
      //   amountInUserC +
      //   (amountInUserC * (UtilityBillFeePersentage / 100) +
      //     UtilityBillFixedFeeInUserCurrency);

      const amountInOurC = parseFloat(
        convertCurrency(amount, currentExhnageRateForBenToOurCurrencyPair)
      );

      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(
        amountInOurC,
        billerDetails.internationalTransactionCurrencyCode,
        userCountryIsoCode
      );
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });

      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES
      // TODO: Should use local amount instead of international ?

      // Checking for minimun amount
      const billMinAmount = billerDetails.minLocalTransactionAmount;
      if (billMinAmount && amount < billMinAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current minimum amount for this bill is ${billMinAmount} ${billerDetails.localTransactionFeeCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      const billMaxAmount = billerDetails.maxLocalTransactionAmount;
      if (billMaxAmount && amount > billMaxAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current maximum amount for this bill is ${billMaxAmount} ${billerDetails.localTransactionFeeCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        user.id,
        "Pay Utility",
        [
          {
            name: `${billerDetailsWithConvertedCurrenys.name} - ${billerDetailsWithConvertedCurrenys.simpleType}`,
            quantity: 1, // need to separate the fee and ammount
            ammountWithFeesInOurC:
              billerDetailsWithConvertedCurrenys.senderFreeOurC + amountWithOurFeesData.baseAmount,
            ammountWithFeesInUsersC:
              billerDetailsWithConvertedCurrenys.senderFeeUserC +
              amountWithOurFeesInUserC.convertedAmount,
            ReloadlyFeesInOurC:
              billerDetailsWithConvertedCurrenys.senderFreeOurC,
            ReloadlyFeesInUserC:
              billerDetailsWithConvertedCurrenys.senderFeeUserC,
            AmmountWithoutFeesInOurC: amountWithOurFeesData.baseAmount,
            AmmountWithoutFeesInUserC: amountWithOurFeesInUserC.convertedAmount,
            subscriberAccountNumber,
            billerId,
            referenceId,
            ammountInBenCurrency: amount,
            benCurrencyCode:
              billerDetailsWithConvertedCurrenys.localTransactionCurrencyCode,
            userCurrencyCode: userCurrencyCode,
          },
        ],
        // "Remove COl",
        amountWithOurFeesData.finalAmountCurrency,
        billerDetailsWithConvertedCurrenys.senderFreeOurC +
        amountWithOurFeesData.finalAmount //+ ourFee    <- This is the grand total
      );

      let redirectUrl;

      if (paymentMethod === CARD) {
        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            billerDetailsWithConvertedCurrenys.name,
            billerDetailsWithConvertedCurrenys.simpleType,
            userCurrencyCode,
            billerDetailsWithConvertedCurrenys.senderFreeOurC,
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(billerDetailsWithConvertedCurrenys.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(billerDetailsWithConvertedCurrenys.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      logger.error("[UtilityCotroller.PayAsGuest] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  TransactionsForThisUser: async (req, res) => {
    try {
      //TODO
      //This endpoint will look at the JWT sent by the clinet, extract our userID from JWT then it will seatch our database for all transactions tied to that user ID
      //as we dont have a DB yet or JWT i will just use a preset array of transaction ID's for testing

      //setps that need done to get to this point;

      //Extract userID from JWT
      //Seatch DB for all transactions for that userID and return an array of transactionIDs

      //TODO add pageation

      const transactionIDs = [3113, 3101, 3100, 3099, 3098, 3097]; //Temp hard coded tid array

      const transactionsPromises = [];

      transactionIDs.forEach(async (tid) => {
        //using a forEatch loop will hit reloadlys api with all these requests at once, will be faster if this works but may cause problems, using a for of loop will be slower but will be more reliable

        transactionsPromises.push(
          //TODO
          //THESE RESPONCES WILL NEED TO BE SANITIZED AS THEY CONTAIN INFO THAT WE DONT WANT THE USER TO KNOW SUCH AS OUR ACCOUNT BALLANCE
          reloadlyUtilityService.GetTransactionInfo(tid)
        );
      });

      // Wait for all requests to finish
      const transactionsDetails = await Promise.all(transactionsPromises);

      res.json(transactionsDetails);
    } catch (e) {
      logger.error("[UtilityCotroller] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },
};
