import { userService } from "../services/database/userService.js";
import logger from "../utils/logger.js";

export const AuthController = {
  Login: async (req, res) => {
    const { password, createdAt, updatedAt, isGuest, ...user } = req.user;
    res.json(user);
  },

  Signup: async (req, res) => {
    try {
      const { firstName, surname, email, phoneNumber, password } = req.body;

      if (!firstName || !surname || !email || !phoneNumber || !password) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const testToSeeIfUserExistsAlready = await userService.getUserByEmail(
        email
      );
      if (testToSeeIfUserExistsAlready) {
        if (!testToSeeIfUserExistsAlready.isGuest) {
          return res.status(409).json({ error: "Account already exists" });
        }

        const user = await userService.UpdateFromGuestToFullAccount(
          testToSeeIfUserExistsAlready.id,
          phoneNumber,
          password
        );

        delete user.password;
        const { createdAt, updatedAt, isGuest, ...FiltedUser } = user;
        return res.status(200).json(FiltedUser);
      }

      const user = await userService.createNewUser(
        firstName,
        surname,
        email,
        phoneNumber,
        password
      );

      delete user.password;
      const { createdAt, updatedAt, isGuest, ...FiltedUser } = user;

      return res.status(200).json(FiltedUser);
    } catch (e) {
      logger.error(`[AuthController.Signup] ${JSON.stringify(e)}`);
      res.status(500).json({ error: "Internal server error" });
    }
  },

  getStatus: async (req, res) => {
    console.log("inside of status");
    console.log(req.user);
    console.log(req.session);
    const { password, createdAt, updatedAt, ...user } = req.user;
    return res.send(user);
  },

  Logout: async (req, res) => {
    if (!req.user) return res.satus(401).json({ error: "user not logged in" });

    req.logOut((e) => {
      if (e) return res.sendStatus(400);
      res.status(200).json("logged out");
    });
  },
};
