// @ts-check

import { prisma } from "../server.js";
import logger from "../utils/logger.js";
import { userService } from "../services/database/userService.js"
import { getCurrencySymbol } from "../services/database/currencies.js";
// import { emailOrderSummary } from "../services/email/email.js"

export const OrderSummaryController = {
    createOrderSummary: async (req, res) => {
        try {

            let { orderData } = req.body;

            // TODO: use 'joi' or 'zod' for validation
            // Check if required fields are present
            if (
                !orderData?.benPhoneNumber
                || !orderData?.benFirstname
                || !orderData?.benSurname
                || !orderData?.benCity
                || !orderData?.benCountry

                || !orderData?.serviceType
                || !orderData?.productType

                // || !orderData?.baseAmount
                // || !orderData?.ourPercentageFee
                // || !orderData?.ourFeeTotal
                // || !orderData?.serviceFee
                || !orderData?.amountToBePaid

                // || !orderData?.transactionAmount
                // || !orderData?.transactionCurrency
                // || !orderData?.transactionCurrencySymbol

                // || !orderData?.senderCurrencyCode

                || !orderData?.senderName
                || !orderData?.senderEmail
                || !orderData?.senderCity
                || !orderData?.senderCountry

                || !orderData?.paymentMethod
                || !orderData?.paymentRequestDetails

                || !orderData?.orderId
            ) {
                return res
                    .status(400)
                    .json({ error: "Invalid request. Missing required fields." });
            }

            // TODO: Check if userId exists in DB

            // In case the sender/buyer/user is a guest. Get the user id directly from database
            if (!orderData.userId) {
                const user = await userService.getUserByEmail(orderData.senderEmail);

                if (!user) {
                    return res.status(404).json({ error: "Could not find the user by email. check the user mail", errorCode: "USER_NOT_FOUND" });
                }

                const { id } = user;

                orderData = { ...orderData, userId: id }
            }

            const senderCurrencyCode = req.localisation.currency.abb;
            const senderCurrencySymbol = (await getCurrencySymbol(senderCurrencyCode)).currencySymbol;

            // TODO: Check if there is already an orderSummary for the orderId submitted
            // TODO: Check if orderId exists in DB

            const result = await prisma.orderSummary.create({
                data: {
                    ...orderData,
                    senderCurrencyCode,
                    senderCurrencySymbol,
                },
            });

            // await emailOrderSummary(result.orderId)

            res.json({ orderSummaryId: result.id });
        } catch (e) {
            logger.error("[OrderSummaryController] \n" + (e));
            res.status(500).json({ error: "Internal server error" });
        }
    },

    getAll: async (req, res) => {
        try {
            console.log("reqUser:", req.user);
            const userId = req.user.id;

            // Parse pagination parameters from the query string
            const page = parseInt(req.query.page) || 1; // Default to page 1
            const pageSize = parseInt(req.query.pageSize) || 10; // Default to 10 items per page

            if (page < 1 || pageSize < 1) {
                return res.status(400).json({ error: 'page and pageSize must be positive integers.' });
            }

            // Calculate the skip value based on the page number and pageSize
            const skip = (page - 1) * pageSize;

            // Fetch paginated data
            const data = await prisma.orderSummary.findMany({
                skip,
                take: pageSize,
                orderBy: {
                    createdAt: 'desc', // Adjust sorting field and order as needed
                },
                where: {
                    userId: {
                        equals: userId,
                    }
                }
            });

            // Fetch total count for calculating total pages
            const totalCount = await prisma.orderSummary.count({
                where: {
                    userId: {
                        equals: userId,
                    }
                }
            });

            res.json({
                data,
                totalPages: Math.ceil(totalCount / pageSize),
                totalCount,
                currentPage: page,
            });
        } catch (e) {
            logger.error("[OrderSummaryController] \n" + (e));
            res.status(500).json({ error: "Internal server error" });
        }
    },
}
