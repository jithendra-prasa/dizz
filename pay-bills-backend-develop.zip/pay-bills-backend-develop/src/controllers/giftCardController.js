// @ts-check

import { ordersDatabaseService } from "../services/database/orders.js";
import { userService } from "../services/database/userService.js";
import { reloadlyGiftCardService } from "../services/reloadly/giftCardService.js";
import { StripeUtilityService } from "../services/stripe/utilityService.js";
import {
  ConvertCardBYIDCurrencys,
  ConvertCardsCurrencys,
  GetCurrentExhnageRate,
  convertCurrency,
} from "../utils/convertCurrency.js";
import logger from "../utils/logger.js";
import { calculateAmountWithFees } from "../services/fees/amountCalculator.js";
import { convertAmountCurrency } from "../services/currencies/converter.js";
import { CARD, CRYPTO, MOBILE_MONEY } from "../constants/paymentMethodConstants.js";
import Decimal from "decimal.js";
import { convertAmountToNPCurrency, createInvoice } from "../services/nowPayments/cryptoService.js";
import { DEFAULT_DECIMAL_PLACES } from "../constants/decimalConstants.js";
import { getSupportedMoMoOperatorsByCountry } from "../services/mobileMoney/momoService.js";
import { v4 as uuidv4 } from 'uuid';
import { requestPawaPayPaymentPage } from "../services/pawaPay/mobileMoneyService.js";

export const GiftCardController = {
  placeholder: async (req, res) => {
    console.log("hit");
    try {
      const serviceResponce = await reloadlyGiftCardService.placeholder();
      res.json(serviceResponce);
    } catch (e) {
      logger.error("[GiftCardCotroller] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  GetCardsByCountry: async (req, res) => {
    try {
      const { country } = req.params;
      const reloadlyResponse = await reloadlyGiftCardService.GetCardsByCountry(
        country
      );

      const resWithConvetedCurrencys = await ConvertCardsCurrencys(
        reloadlyResponse,
        req.localisation.currency.abb
      );

      res.json(resWithConvetedCurrencys);
    } catch (e) {
      logger.error(
        "[GiftCardCotroller.GetCardsByCountry] " + JSON.stringify(e)
      );
      res.status(500).json({ error: "Internal server error" });
    }
  },

  Pay: async (req, res) => {
    try {
      console.log(req.body);
      const { benName, amount, productId, referenceId, userID, paymentMethod } = req.body;

      // Check if required fields are present
      if (!benName || !amount || !productId || !userID || !paymentMethod) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        benName,
        amount,
        productId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      // Conditionally add referenceId if it is defined
      if (referenceId !== undefined) {
        fields.referenceId = referenceId;
      }

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const giftCardDetails = await ConvertCardBYIDCurrencys(
        await reloadlyGiftCardService.GetGiftCardDetails(productId),
        userCurrencyCode
      );

      const exhangeRateForCurrecnyPair = await GetCurrentExhnageRate(
        userCurrencyCode,
        giftCardDetails.senderCurrencyCode
      );

      let amountInOurReloadlyCurrency;
      let ammountInCardVenderCurrency;

      // If gift card possible amounts are fixed
      if (giftCardDetails.fixedSenderDenominationsUserC) {
        // TODO: Should error when fixed amount index is not found
        const index =
          giftCardDetails.fixedSenderDenominationsUserC.indexOf(amount);
        console.log(index);
        console.log(amount);

        amountInOurReloadlyCurrency =
          giftCardDetails.fixedSenderDenominationsOurC[index];

        ammountInCardVenderCurrency =
          giftCardDetails.fixedRecipientDenominations[index];
      }
      // If gift card possible amounts are included in a range
      else {
        amountInOurReloadlyCurrency = parseFloat(
          convertCurrency(amount, exhangeRateForCurrecnyPair)
        );

        // TODO: This is causing an error when trying to order giftcard. Fix it
        // ammountInCardVenderCurrency = "N/A - Custom Range";

        // TODO: Reloadly having different fx rates. Plan to replace this for a more precise conversion. For now, price range validation might fail if amount too close to any of the ranges
        ammountInCardVenderCurrency = (await convertAmountCurrency(amount, userCurrencyCode, giftCardDetails.recipientCurrencyCode)).convertedAmount;

        // const giftcardFixedFee = 0.75; //todo pull these values form a table in mysql
        // const giftcardFeePersentage = 20;

        // amountInOurReloadlyCurrency =
        //   amountInOurReloadlyCurrency -
        //   (amountInOurReloadlyCurrency * (giftcardFeePersentage / 100) +
        //     giftcardFixedFee);
      }

      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(amountInOurReloadlyCurrency, giftCardDetails.senderCurrencyCode, userCountryIsoCode);
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });

      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES

      // Checking for minimun amount
      // const giftCardMinAmount = giftCardDetails.minSenderDenomination;
      const giftCardMinAmount = giftCardDetails.minRecipientDenomination;
      if (
        // giftCardMinAmount && amountInOurReloadlyCurrency < giftCardMinAmount || 
        giftCardMinAmount && ammountInCardVenderCurrency < giftCardMinAmount
      ) {
        return res
          .status(400)
          .json({
            // error: `Invalid amount provided, the current minimum amount for this gift card is ${giftCardMinAmount} ${giftCardDetails.senderCurrencyCode}`,
            // TODO: Review this error message. Potentially misleading
            error: `Invalid amount provided, the current minimum amount for this gift card is ${giftCardMinAmount} ${giftCardDetails.recipientCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      // const giftCardMaxAmount = giftCardDetails.maxSenderDenomination;
      const giftCardMaxAmount = giftCardDetails.maxRecipientDenomination;
      if (
        // giftCardMaxAmount && amountInOurReloadlyCurrency > giftCardMaxAmount || 
        giftCardMaxAmount && ammountInCardVenderCurrency > giftCardMaxAmount
      ) {
        return res
          .status(400)
          .json({
            // error: `Invalid amount provided, the current maximum amount for this gift card is ${giftCardMaxAmount} ${giftCardDetails.senderCurrencyCode}`,
            // TODO: Review this error message. Potentially misleading
            error: `Invalid amount provided, the current maximum amount for this gift card is ${giftCardMaxAmount} ${giftCardDetails.recipientCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      // Getting user by id
      const user = await userService.GetUser(userID);

      // Checking if user exists
      if (!user) {
        return res.status(404).json({ error: "No user found for that Id", errorCode: "USER_NOT_FOUND" });
      }

      // Extracting user email
      const { email } = user;

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        userID,
        "GiftCard",
        [
          {
            name: giftCardDetails.productName,
            quantity: 1,
            userCurrency: userCurrencyCode,
            ammountWithFeesUserC: giftCardDetails.senderFeeUserC + amountWithOurFeesInUserC.convertedAmount,
            ammountWithFeesOurC:
              parseFloat(giftCardDetails.senderFreeOurC) +
              amountWithOurFeesData.baseAmount,
            ReloadlyFeesOurC: parseFloat(giftCardDetails.senderFreeOurC), // TODO - Same here as above comment
            AmmountWithoutFeesUserC: amountWithOurFeesInUserC.convertedAmount, //ammount included our fees
            AmmountWithoutFeesOurC: amountWithOurFeesData.baseAmount,
            ammountInCardVenderCurrency,
            benName,
            productId,
            referenceId,
          },
        ],
        // "Remove col",
        amountWithOurFeesData.finalAmountCurrency,
        parseFloat(giftCardDetails.senderFreeOurC) +
        amountWithOurFeesData.finalAmount //+ ourFee in included in ammount     <- This is the grand total   TODO - Same here as above comment
      );

      let redirectUrl;

      if (paymentMethod === CARD) {
        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            giftCardDetails.productName,
            "GiftCard",
            userCurrencyCode,
            giftCardDetails.senderFreeOurC,
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(giftCardDetails.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(giftCardDetails.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      logger.error("[GiftCardCotroller.Pay] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  PayAsGuest: async (req, res) => {
    try {
      console.log(req.body);
      const {
        benName,
        amount,
        productId,
        referenceId,
        firstName,
        surname,
        email,
        paymentMethod
      } = req.body;

      // Check if required fields are present
      if (
        !benName ||
        !amount ||
        !productId ||
        !firstName ||
        !surname ||
        !email ||
        !paymentMethod
      ) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        benName,
        amount,
        productId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      // Conditionally add referenceId if it is defined
      if (referenceId !== undefined) {
        fields.referenceId = referenceId;
      }

      const user =
        (await userService.getUserByEmail(email)) ||
        (await userService.createGuestUser(firstName, surname, email));

      if (!user.isGuest) {
        return res.status(401).json({ error: "This email is already in use" });
      }

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const giftCardDetails = await ConvertCardBYIDCurrencys(
        await reloadlyGiftCardService.GetGiftCardDetails(productId),
        userCurrencyCode
      );

      const exhangeRateForCurrecnyPair = await GetCurrentExhnageRate(
        userCurrencyCode,
        giftCardDetails.senderCurrencyCode
      );

      let amountInOurReloadlyCurrency;
      let ammountInCardVenderCurrency;

      // If gift card possible amounts are fixed
      if (giftCardDetails.fixedSenderDenominationsUserC) {
        // TODO: Should error when fixed amount index is not found
        const index =
          giftCardDetails.fixedSenderDenominationsUserC.indexOf(amount);
        console.log(index);
        console.log(amount);

        amountInOurReloadlyCurrency =
          giftCardDetails.fixedSenderDenominationsOurC[index];

        ammountInCardVenderCurrency =
          giftCardDetails.fixedRecipientDenominations[index];
      }
      // If gift card possible amounts are included in a range
      else {
        amountInOurReloadlyCurrency = parseFloat(
          convertCurrency(amount, exhangeRateForCurrecnyPair)
        );

        // TODO: This is causing an error when trying to order giftcard. Fix it
        // ammountInCardVenderCurrency = "N/A - Custom Range";

        // TODO: Reloadly having different fx rates. Plan to replace this for a more precise conversion. For now, price range validation might fail if amount too close to any of the ranges
        ammountInCardVenderCurrency = (await convertAmountCurrency(amount, userCurrencyCode, giftCardDetails.recipientCurrencyCode)).convertedAmount;

        // const giftcardFixedFee = 0.75; //todo pull these values form a table in mysql
        // const giftcardFeePersentage = 20;

        // amountInOurReloadlyCurrency =
        //   amountInOurReloadlyCurrency -
        //   (amountInOurReloadlyCurrency * (giftcardFeePersentage / 100) +
        //     giftcardFixedFee);
      }

      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(amountInOurReloadlyCurrency, giftCardDetails.senderCurrencyCode, userCountryIsoCode);
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });

      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES

      // Checking for minimun amount
      // const giftCardMinAmount = giftCardDetails.minSenderDenomination;
      const giftCardMinAmount = giftCardDetails.minRecipientDenomination;
      if (
        // giftCardMinAmount && amountInOurReloadlyCurrency < giftCardMinAmount || 
        giftCardMinAmount && ammountInCardVenderCurrency < giftCardMinAmount
      ) {
        return res
          .status(400)
          .json({
            // error: `Invalid amount provided, the current minimum amount for this gift card is ${giftCardMinAmount} ${giftCardDetails.senderCurrencyCode}`,
            // TODO: Review this error message. Potentially misleading
            error: `Invalid amount provided, the current minimum amount for this gift card is ${giftCardMinAmount} ${giftCardDetails.recipientCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      // const giftCardMaxAmount = giftCardDetails.maxSenderDenomination;
      const giftCardMaxAmount = giftCardDetails.maxRecipientDenomination;
      if (
        // giftCardMaxAmount && amountInOurReloadlyCurrency > giftCardMaxAmount ||
        giftCardMaxAmount && ammountInCardVenderCurrency > giftCardMaxAmount
      ) {
        return res
          .status(400)
          .json({
            // error: `Invalid amount provided, the current maximum amount for this gift card is ${giftCardMaxAmount} ${giftCardDetails.senderCurrencyCode}`,
            // TODO: Review this error message. Potentially misleading
            error: `Invalid amount provided, the current maximum amount for this gift card is ${giftCardMaxAmount} ${giftCardDetails.recipientCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        user.id,
        "GiftCard",
        [
          {
            name: giftCardDetails.productName,
            quantity: 1,
            userCurrency: userCurrencyCode,
            ammountWithFeesUserC: giftCardDetails.senderFeeUserC + amountWithOurFeesInUserC.convertedAmount,
            ammountWithFeesOurC:
              parseFloat(giftCardDetails.senderFreeOurC) +
              amountWithOurFeesData.baseAmount,
            ReloadlyFeesOurC: parseFloat(giftCardDetails.senderFreeOurC), // TODO - Same here as above comment
            AmmountWithoutFeesUserC: amountWithOurFeesInUserC.convertedAmount, //ammount included our fees
            AmmountWithoutFeesOurC: amountWithOurFeesData.baseAmount,
            ammountInCardVenderCurrency,
            benName,
            productId,
            referenceId,
          },
        ],
        // "Remove col",
        amountWithOurFeesData.finalAmountCurrency,
        parseFloat(giftCardDetails.senderFreeOurC) +
        amountWithOurFeesData.finalAmount //+ ourFee in included in ammount     <- This is the grand total   TODO - Same here as above comment
      );

      let redirectUrl;

      if (paymentMethod === CARD) {
        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            giftCardDetails.productName,
            "GiftCard",
            userCurrencyCode,
            giftCardDetails.senderFreeOurC,
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(giftCardDetails.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(giftCardDetails.senderFreeOurC).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      logger.error("[GiftCardCotroller.PayAsGuest] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },
};
