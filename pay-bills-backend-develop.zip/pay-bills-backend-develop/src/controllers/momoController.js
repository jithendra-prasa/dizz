//@ts-check

import logger from "../utils/logger.js";
import { prisma } from "../server.js";

// Mobile Money (MoMo) controllers
export const MomoController = {
    getSupportedCountries: async (req, res) => {
        try {
            const data = await prisma.momoCountry.findMany({
                where: {
                    momoProvider: {
                        status: true,
                    }
                },
                select: {
                    // id: true,
                    countryIso2: true,
                    countryIso3: true,
                    countryInfo: {
                        select: {
                            // id: true,
                            name: true,
                            // isoCode: true,
                            currencies: {
                                select: {
                                    name: true,
                                }
                            },
                            callingCodes: {
                                select: {
                                    code: true
                                }
                            },
                        }
                    },
                    supportedOperators: {
                        where: {
                            status: true
                        },
                        select: {
                            // id: true,
                            name: true,
                            momoName: true,
                        }
                    },
                },
                orderBy: {
                    countryInfo: {
                        name: "asc"
                    },
                },
            });

            res.json({ data });
        } catch (e) {
            logger.error("[MomoController] \n" + (e));
            res.status(500).json({ error: "Internal server error" });
        }
    },

}
