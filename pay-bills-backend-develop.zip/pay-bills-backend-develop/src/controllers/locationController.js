// @ts-check

import logger from "../utils/logger.js";
import { retrieveLocationDataQuery } from "../services/database/location.js"

export const LocationController = {
    getLocationData: async (req, res) => {
        try {
            const city = req.ipInfo.city;

            // To get country full name instead of the iso code only
            const country = req.localisation.country.name;

            // Getting user country code
            const userCountryIsoCode = req.ipInfo.country;
            const countryInfo = await retrieveLocationDataQuery(userCountryIsoCode);
            const continents = countryInfo?.continents.map((continent) => continent.name);

            res.json({ name: country, city, continents: continents });
        } catch (e) {
            logger.error("[LocationController] \n" + (e));
            res.status(500).json({ error: "Internal server error" });
        }
    },

    getLocationDataByCountryCode: async (req, res) => {
        try {
            const { isoCode } = req.body;

            if (!isoCode) {
                return res
                    .status(400)
                    .json({ error: "Invalid request. Missing required fields." });
            }

            const country = await retrieveLocationDataQuery(isoCode);

            if (!country) {
                res.status(404).json({ error: "No location data found for that country. Make sure the country ISO code is correct" });
            }

            res.json(country);
        } catch (e) {
            logger.error("[LocationController] \n" + e);
            res.status(500).json({ error: "Internal server error" });
        }
    },

}