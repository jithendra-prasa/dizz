// @ts-check

import Decimal from "decimal.js";
import { STRIPE_TRANSACTION_CURRENCY } from "../constants/stripeConstants.js";
import { convertAmountCurrency } from "../services/currencies/converter.js";
import { calculateAmountWithFees } from "../services/fees/amountCalculator.js";
import { getReloadlyProductFees } from "../services/fees/reloadlyProductFees.js";
import logger from "../utils/logger.js";
import { DEFAULT_DECIMAL_PLACES } from "../constants/decimalConstants.js";
import { getCurrencySymbol } from "../services/database/currencies.js";

export const AmountFeesController = {
    // TODO: Improve request with caching, etc.
    calculateAmountAndFees: async (req, res) => {
        try {

            // Getting request data
            const { amount, currency, countryIsoCode, serviceType, serviceProductId } = req.body;

            // Check if required fields are present
            if (!amount || !serviceType || !serviceProductId) {
                return res
                    .status(400)
                    .json({ error: "Invalid request. Missing required fields." });
            }

            // Getting user currency
            // TODO: check if it is utility before using "currency"
            const userCurrency = currency || req.localisation.currency.abb;

            // Getting user country iso code
            const userCountryIsoCode = countryIsoCode || req.ipInfo.country;

            // Calculating our fees
            const amountWithFeesData = await calculateAmountWithFees(amount, userCurrency, userCountryIsoCode);

            // Retrieving reloadly product fees
            const reloadlyProductFees = await getReloadlyProductFees(serviceType, serviceProductId);

            // If reloadly product fees are not found
            if (!reloadlyProductFees) {
                return res.status(404).json({
                    error: "Couldn't get product service fees. Check serviceType and serviceProductId. Or try again later.",
                    errorCode: "SERVICE_NOT_FOUND"
                });
            }

            // Converting reloadly product fees into user currency
            const convertedReloadlyProductFees = await convertAmountCurrency(
                reloadlyProductFees.serivceFee,
                reloadlyProductFees.serviceFeeCurrency,
                userCurrency
            );

            // Total amount to pay in user currency (by adding base amount + our fees + reloadly product fees)
            // const totalAmount = amountWithFeesData.finalAmount + convertedReloadlyProductFees.convertedAmount;

            const finalAmountDecimal = new Decimal(amountWithFeesData.finalAmount);
            const convertedReloadlyProductFeesDecimal = new Decimal(convertedReloadlyProductFees.convertedAmount);

            // * => amountWithFeesData.finalAmount + convertedReloadlyProductFees.convertedAmount;
            const totalAmountDecimal = finalAmountDecimal.plus(convertedReloadlyProductFeesDecimal);

            // Total amount to pay in user currency (by adding base amount + our fees + reloadly product fees)
            const totalAmount = totalAmountDecimal.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber();

            // Converting total amount to pay in stripe transaction currency
            const convertedTotalAmount = await convertAmountCurrency(totalAmount, userCurrency, STRIPE_TRANSACTION_CURRENCY);
            const stripeTransactionAmount = convertedTotalAmount.convertedAmount;

            const stripeTransactionCurrencySymbol = (await getCurrencySymbol(STRIPE_TRANSACTION_CURRENCY)).currencySymbol;

            res.json({
                // ...amountWithFeesData,
                baseAmount: amountWithFeesData.baseAmount,
                baseCurrency: amountWithFeesData.baseCurrency,

                ourPercentageFee: amountWithFeesData.percentageFee,
                ourFeeTotal: amountWithFeesData.totalFee,
                ourFeeCurrency: amountWithFeesData.feeCurrency,

                serviceFee: convertedReloadlyProductFees.convertedAmount,
                serviceFeeCurrency: convertedReloadlyProductFees.targetCurrency,

                totalAmount,
                totalAmountCurrency: userCurrency,

                stripeTransactionAmount,
                stripeTransactionCurrency: STRIPE_TRANSACTION_CURRENCY,
                stripeTransactionCurrencySymbol
            });
        } catch (e) {
            logger.error("[AmountFeesController] \n" + (e));
            res.status(500).json({ error: "Internal server error" });
        }
    },

}

