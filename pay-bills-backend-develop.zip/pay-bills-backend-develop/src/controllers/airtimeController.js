// @ts-check

import { reloadlyAirtimeService } from "../services/reloadly/airtimeService.js";
import { userService } from "../services/database/userService.js";
import { ordersDatabaseService } from "../services/database/orders.js";
import { StripeUtilityService } from "../services/stripe/utilityService.js";
import {
  ConvertAirtimeOperatorByIDCurrency,
  ConvertAirtimeOperatorsCurrencys,
  GetCurrentExhnageRate,
  convertCurrency,
} from "../utils/convertCurrency.js";
import logger from "../utils/logger.js";
import { calculateAmountWithFees } from "../services/fees/amountCalculator.js";
import { convertAmountCurrency } from "../services/currencies/converter.js";
import { CARD, CRYPTO, MOBILE_MONEY } from "../constants/paymentMethodConstants.js";
import { convertAmountToNPCurrency, createInvoice } from "../services/nowPayments/cryptoService.js";
import Decimal from "decimal.js";
import { DEFAULT_DECIMAL_PLACES } from "../constants/decimalConstants.js";
import { getSupportedMoMoOperatorsByCountry } from "../services/mobileMoney/momoService.js";
import { requestPawaPayPaymentPage } from "../services/pawaPay/mobileMoneyService.js";
import { v4 as uuidv4 } from 'uuid';

export const AirtimeController = {
  placeholder: async (req, res) => {
    console.log("hit");
    try {
      const serviceResponce = await reloadlyAirtimeService.placeholder();
      res.json(serviceResponce);
    } catch (e) {
      console.error("Error" + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  // Countries: async (req, res) => {
  //   try {
  //     const reloadlyResponce = await reloadlyAirtimeService.GetCountries();
  //     res.json(reloadlyResponce);
  //   } catch (e) {
  //     console.error("Error with getting countries from airtime controller" + e);
  //     res.status(500).json({ error: "Internal server error" });
  //   }
  // },

  Operators: async (req, res) => {
    try {
      const reloadlyResponce = await reloadlyAirtimeService.GetOperators();
      res.json(reloadlyResponce);
    } catch (e) {
      logger.error("[AirtimeController.Operators] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  GetOperatorById: async (req, res) => {
    try {
      const { operatorId } = req.params;
      const reloadlyResponse = await reloadlyAirtimeService.GetOperatorById(
        operatorId
      );
      res.json(reloadlyResponse);
    } catch (e) {
      logger.error("[AirtimeController.GetOperatorById] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  Pay: async (req, res) => {
    try {
      console.log(req.body);
      const {
        recipientPhone,
        amount,
        operatorId,
        customIdentifier,
        userID,
        recipientcountryCode,
        paymentMethod
      } = req.body;

      // Check if required fields are present
      if (
        !recipientPhone ||
        !amount ||
        !operatorId ||
        !userID ||
        !recipientcountryCode ||
        !paymentMethod
      ) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        recipientPhone,
        amount,
        operatorId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      console.log({
        recipientPhone,
        amount,
        operatorId,
        customIdentifier,
        userID,
        recipientcountryCode,
      });

      // Conditionally add customIdentifier if it is defined
      if (customIdentifier !== undefined) {
        fields.customIdentifier = customIdentifier;
      }

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const operatorDetails = await ConvertAirtimeOperatorByIDCurrency(
        await reloadlyAirtimeService.GetOperatorById(operatorId),
        userCurrencyCode
      );

      const exhangeRateForCurrecnyPair = await GetCurrentExhnageRate(
        userCurrencyCode,
        operatorDetails.senderCurrencyCode
      );

      let amountInOurReloadlyCurrency;

      // If operator possible amounts are fixed
      if (operatorDetails.fixedAmounts.length > 0) {
        const keysOfFixedAmountsDescriptions = Object.keys(
          operatorDetails.fixedAmountsDescriptions
        );

        // TODO: Should error when fixed amount index is not found
        const index = keysOfFixedAmountsDescriptions.indexOf(amount.toString());
        console.log(keysOfFixedAmountsDescriptions);
        console.log(amount.toString());

        amountInOurReloadlyCurrency = operatorDetails.fixedAmounts[index];
      }
      // If operator possible amounts are included in a range
      else {
        amountInOurReloadlyCurrency = parseFloat(
          convertCurrency(amount, exhangeRateForCurrecnyPair)
        );

        // const airtimeFixedFee = 0.75; //todo pull these values form a table in mysql
        // const airtimeFeePersentage = 20;

        // amountInOurReloadlyCurrency =
        //   amountInOurReloadlyCurrency -
        //   (amountInOurReloadlyCurrency * (airtimeFeePersentage / 100) +
        //     airtimeFixedFee);
      }


      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(amountInOurReloadlyCurrency, operatorDetails.senderCurrencyCode, userCountryIsoCode);
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });


      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES

      // Checking for minimun amount
      const operatorMinAmount = operatorDetails.minAmount;
      if (operatorMinAmount && amountInOurReloadlyCurrency < operatorMinAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current minimum amount for this operator is ${operatorMinAmount} ${operatorDetails.senderCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      const operatorMaxAmount = operatorDetails.maxAmount;
      if (operatorMaxAmount && amountInOurReloadlyCurrency > operatorMaxAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current maximum amount for this operator is ${operatorMaxAmount} ${operatorDetails.senderCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      const TopupPackage = "Placeholder";

      // Getting user by id
      const user = await userService.GetUser(userID);

      // Checking if user exists
      if (!user) {
        return res.status(404).json({ error: "No user found for that Id", errorCode: "USER_NOT_FOUND" });
      }

      // Extracting user email
      const { email } = user;

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        userID,
        "Airtime",
        [
          {
            name: `${operatorDetails.name} - ${TopupPackage}`,
            quantity: 1, // need to separate the fee and ammount
            userCurrency: userCurrencyCode,
            ammountWithFeesUserC: operatorDetails.fees.international + amountWithOurFeesInUserC.convertedAmount,
            ammountWithFeesOurC:
              parseFloat(
                operatorDetails.fees.internationalInOurReloadlyCurrrency
              ) + amountWithOurFeesData.baseAmount,
            ReloadlyFeesOurC: parseFloat(
              operatorDetails.fees.internationalInOurReloadlyCurrrency
            ), // TODO - Same here as above comment
            AmmountWithoutFeesUserC: amountWithOurFeesInUserC.convertedAmount, //ammount included our fees
            AmmountWithoutFeesOurC: amountWithOurFeesData.baseAmount,
            recipientPhone,
            recipientcountryCode,
            operatorId,
            customIdentifier,
          },
        ],
        // "Remove col",
        amountWithOurFeesData.finalAmountCurrency,
        parseFloat(operatorDetails.fees.internationalInOurReloadlyCurrrency) +
        amountWithOurFeesData.finalAmount //+ ourFee in included in ammount     <- This is the grand total   TODO - Same here as above comment
      );

      let redirectUrl;

      if (paymentMethod === CARD) {

        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            operatorDetails.name,
            TopupPackage,
            userCurrencyCode,
            operatorDetails.fees.international, // TODO - Same here as above comment
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(operatorDetails.fees.international).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(operatorDetails.fees.international).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      console.error("Error" + e);
      logger.error("[AirtimeController.Pay] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  PayAsGuest: async (req, res) => {
    try {
      console.log(req.body);
      const {
        recipientPhone,
        amount,
        operatorId,
        customIdentifier,
        recipientcountryCode,
        firstName,
        surname,
        email,
        paymentMethod
      } = req.body;

      // Check if required fields are present
      if (
        !recipientPhone ||
        !amount ||
        !operatorId ||
        !recipientcountryCode ||
        !firstName ||
        !surname ||
        !email ||
        !paymentMethod
      ) {
        return res
          .status(400)
          .json({ error: "Invalid request. Missing required fields." });
      }

      const fields = {
        recipientPhone,
        amount,
        operatorId,
        useLocalAmount: false, //need to check but its probs best to keeps this false - useLocalAmount:  Indicates if the amount being presented is in the local currency of the biller. If this parameter is not provided or is set to false, then the payment will be presented in the user’s wallet currency.
      };

      console.log({
        recipientPhone,
        amount,
        operatorId,
        customIdentifier,
        recipientcountryCode,
        firstName,
        surname,
        email,
      });

      // Conditionally add customIdentifier if it is defined
      if (customIdentifier !== undefined) {
        fields.customIdentifier = customIdentifier;
      }

      const user =
        (await userService.getUserByEmail(email)) ||
        (await userService.createGuestUser(firstName, surname, email));

      if (!user.isGuest) {
        return res.status(401).json({ error: "This email is already in use" });
      }

      // Getting user currency code
      const userCurrencyCode = req.localisation.currency.abb;

      // Getting user country code
      const userCountryIsoCode = req.ipInfo.country;

      if (!userCountryIsoCode) {
        return res.status(404).json({
          error: "Invalid request. Unable to determine user country.",
          errorCode: "INVALID_COUNTRY"
        });
      }

      let supportedMoMoForUserCountry = null;

      // Check if the user country is supported for mobile money
      if (paymentMethod === MOBILE_MONEY) {
        supportedMoMoForUserCountry = await getSupportedMoMoOperatorsByCountry(userCountryIsoCode);

        if (!supportedMoMoForUserCountry || supportedMoMoForUserCountry.length === 0) {
          return res.status(404).json({
            error: "No supported mobile money operators for this country",
            errorCode: "NO_SUPPORTED_MOMO"
          });
        }
      }

      const operatorDetails = await ConvertAirtimeOperatorByIDCurrency(
        await reloadlyAirtimeService.GetOperatorById(operatorId),
        userCurrencyCode
      );

      const exhangeRateForCurrecnyPair = await GetCurrentExhnageRate(
        userCurrencyCode,
        operatorDetails.senderCurrencyCode
      );

      let amountInOurReloadlyCurrency;

      // If operator possible amounts are fixed
      if (operatorDetails.fixedAmounts.length > 0) {
        const keysOfFixedAmountsDescriptions = Object.keys(
          operatorDetails.fixedAmountsDescriptions
        );

        // TODO: Should error when fixed amount index is not found
        const index = keysOfFixedAmountsDescriptions.indexOf(amount.toString());
        console.log(keysOfFixedAmountsDescriptions);
        console.log(amount.toString());

        amountInOurReloadlyCurrency = operatorDetails.fixedAmounts[index];
      }
      // If operator possible amounts are included in a range
      else {
        amountInOurReloadlyCurrency = parseFloat(
          convertCurrency(amount, exhangeRateForCurrecnyPair)
        );

        // const airtimeFixedFee = 0.75; //todo pull these values form a table in mysql
        // const airtimeFeePersentage = 20;

        // amountInOurReloadlyCurrency =
        //   amountInOurReloadlyCurrency -
        //   (amountInOurReloadlyCurrency * (airtimeFeePersentage / 100) +
        //     airtimeFixedFee);
      }

      // Calculating amount fees and final amount. Is in reloadly account currency (normally "EUR")
      const amountWithOurFeesData = await calculateAmountWithFees(amountInOurReloadlyCurrency, operatorDetails.senderCurrencyCode, userCountryIsoCode);
      console.log({ amountWithOurFeesData });

      // Converting final amount (our fees included) to user currency for stripe API (& others)
      const amountWithOurFeesInUserC = await convertAmountCurrency(
        amountWithOurFeesData.finalAmount,
        amountWithOurFeesData.finalAmountCurrency,
        userCurrencyCode
      );
      console.log({ amountWithOurFeesInUserC });


      // * CHECKING IF PROVIDED AMOUNT IS INCLUDED IN PRODUCT PRICE RANGES

      // Checking for minimun amount
      const operatorMinAmount = operatorDetails.minAmount;
      if (operatorMinAmount && amountInOurReloadlyCurrency < operatorMinAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current minimum amount for this operator is ${operatorMinAmount} ${operatorDetails.senderCurrencyCode}`,
            errorCode: "AMOUNT_TOO_LOW"
          });
      }

      // Checking for maximum amount
      const operatorMaxAmount = operatorDetails.maxAmount;
      if (operatorMaxAmount && amountInOurReloadlyCurrency > operatorMaxAmount) {
        return res
          .status(400)
          .json({
            error: `Invalid amount provided, the current maximum amount for this operator is ${operatorMaxAmount} ${operatorDetails.senderCurrencyCode}`,
            errorCode: "AMOUNT_TOO_HIGH"
          });
      }

      const TopupPackage = "Placeholder";

      const { id: orderID } = await ordersDatabaseService.CreateNewOrder(
        user.id,
        "Airtime",
        [
          {
            name: `${operatorDetails.name} - ${TopupPackage}`,
            quantity: 1, // need to separate the fee and ammount
            userCurrency: userCurrencyCode,
            ammountWithFeesUserC: operatorDetails.fees.international + amountWithOurFeesInUserC.convertedAmount,
            ammountWithFeesOurC:
              parseFloat(
                operatorDetails.fees.internationalInOurReloadlyCurrrency
              ) + amountWithOurFeesData.baseAmount,
            ReloadlyFeesOurC: parseFloat(
              operatorDetails.fees.internationalInOurReloadlyCurrrency
            ), // TODO - Same here as above comment
            AmmountWithoutFeesUserC: amountWithOurFeesInUserC.convertedAmount, //ammount included our fees
            AmmountWithoutFeesOurC: amountWithOurFeesData.baseAmount,
            recipientPhone,
            recipientcountryCode,
            operatorId,
            customIdentifier,
          },
        ],
        // "Remove col",
        amountWithOurFeesData.finalAmountCurrency,
        parseFloat(operatorDetails.fees.internationalInOurReloadlyCurrrency) +
        amountWithOurFeesData.finalAmount //+ ourFee in included in ammount     <- This is the grand total   TODO - Same here as above comment
      );

      let redirectUrl;

      if (paymentMethod === CARD) {
        const stripeResponce =
          await StripeUtilityService.CreateCheckoutForSingleUtility(
            operatorDetails.name,
            TopupPackage,
            userCurrencyCode,
            operatorDetails.fees.international, // TODO - Same here as above comment
            amountWithOurFeesInUserC.convertedAmount,
            orderID,
            email
          );

        redirectUrl = stripeResponce.url;
      } else if (paymentMethod === CRYPTO) {
        const amountTotalToPay = new Decimal(operatorDetails.fees.international).add(new Decimal(amountWithOurFeesInUserC.convertedAmount));

        const convertedAmountTotalToPay = await convertAmountToNPCurrency(amountTotalToPay.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber(), userCurrencyCode)

        const invoiceResponse = await createInvoice({
          price_amount: convertedAmountTotalToPay.convertedAmount,
          price_currency: convertedAmountTotalToPay.targetCurrency,
          order_id: orderID.toString()
        });

        redirectUrl = invoiceResponse.invoice_url;
      } else if (paymentMethod === MOBILE_MONEY) {
        const amountTotalToPay = new Decimal(operatorDetails.fees.international).add(new Decimal(amountWithOurFeesInUserC.convertedAmount)).toDecimalPlaces(0);

        // Just to hide nullable error. At this point we're certain that the value is not null
        if (!supportedMoMoForUserCountry) {
          return;
        }

        const pawaPayDepositId = uuidv4();

        await ordersDatabaseService.updateOrderPawapayDepositId(orderID, pawaPayDepositId);

        const pawaPayResponse = await requestPawaPayPaymentPage({
          amount: amountTotalToPay.toString(),
          country: supportedMoMoForUserCountry[0].countryIso3,
          depositId: pawaPayDepositId,
          metadata: [{
            fieldName: "orderId",
            fieldValue: orderID.toString(),
          },]
        })

        redirectUrl = pawaPayResponse.redirectUrl;
      }

      res.json({ url: redirectUrl, orderID });
    } catch (e) {
      logger.error("[AirtimeController.PayAsGuest] " + JSON.stringify(e));
      res.status(500).json({ error: "Internal server error" });
    }
  },

  GetTransactionInfo: async (req, res) => {
    try {
      const transactionId = req.body;
      const reloadlyResponse = await reloadlyAirtimeService.GetTransactionInfo(
        transactionId
      );
      res.json(reloadlyResponse);
    } catch (e) {
      logger.error(
        "[AirtimeController.GetTransactionInfo] " + JSON.stringify(e)
      );
      res.status(500).json({ error: "Internal server error" });
    }
  },

  GetOperatorByCountry: async (req, res) => {
    try {
      const { country } = req.params;
      const reloadlyResponse =
        await reloadlyAirtimeService.GetOperatorByCountry(country);

      //todo if users currencys is the same as reloadly currenty then return early

      const resWithConvetedCurrencys = await ConvertAirtimeOperatorsCurrencys(
        reloadlyResponse,
        req.localisation.currency.abb
      );

      res.json(resWithConvetedCurrencys);
    } catch (e) {
      logger.error(
        "[AirtimeController.GetOperatorByCountry] " + JSON.stringify(e)
      );
      res.status(500).json({ error: "Internal server error" });
    }
  },

  AutoDetectOperator: async (req, res) => {
    try {
      const { phoneNumber, countryCode } = req.query;

      const reloadlyResponce = await reloadlyAirtimeService.AutoDetectOperator(
        phoneNumber,
        countryCode
      );

      res.json(reloadlyResponce);
    } catch (e) {
      logger.error(
        "[AirtimeController.AutoDetectOperator] " + JSON.stringify(e)
      );
      res.status(500).json({ error: "Internal server error" });
    }
  },
};