import Stripe from "stripe";
import { StripeWebhookService } from "../services/stripe/webhookService.js";
import logger from "../utils/logger.js";

export const StripeController = {
  HandelWebHook: async (req, res) => {
    const sig = req.headers["stripe-signature"];
    let event;

    try {
      const stripe = new Stripe(process.env.STRIPE_PRIVATE_KEY);
      event = stripe.webhooks.constructEvent(
        req.body,
        sig,
        process.env.STRIPE_WEBHOOKSECRET
      );
    } catch (err) {
      logger.error(`[StripeController.HandelWebHook] - ${JSON.stringify(err)}`);
      res.status(400).send(`Webhook Error: ${err.message}`);
      throw new Error(err);
    }

    // Process the event
    try {
      await StripeWebhookService.processEvent(event);
      res.send();
    } catch (err) {
      logger.error(`[StripeController.HandelWebHook] - ${JSON.stringify(err)}`);
      res.status(500).send(`Internal Server Error: ${err.message}`);
      throw new Error(err);
    }
  },
};
