//@ts-check

import crypto from 'crypto';
import logger from "../utils/logger.js";
import { z } from 'zod';
import { NPWebhookResponseSchema } from '../models/nowPaymentsSchema.js';
import { processNPWebhookEvent } from '../services/nowPayments/webhookService.js';

const nowPaymentsIpnKey = process.env.NOW_PAYMENTS_IPN_KEY

export const NowPaymentsController = {
    handleWebhook: async (req, res) => {
        try {
            const requestHeaders = req.headers;

            /** @type {z.infer<typeof NPWebhookResponseSchema>} */
            const requestBody = req.body;

            // * Getting HMAC signature present in the request headers
            /** @type {string} */
            const nowPaymentsSignature = requestHeaders["x-nowpayments-sig"];

            // console.log("NOWPayments callback request headers", requestHeaders);
            // console.log("NOWPayments callback request body", requestBody);
            // console.log({ requestHeaders });

            // If NOW_PAYMENTS_IPN_KEY is absent from .env variables
            if (!nowPaymentsIpnKey) {
                logger.error("'NOW_PAYMENTS_IPN_KEY' not found. Check the env variables");

                return res.status(500).json({ error: "Internal server error" });
            }

            // * Checking HMAC signature with IPN secret key, to make sure the request came from NOWPayments (and that it is the right account)
            const hmac = crypto.createHmac('sha512', nowPaymentsIpnKey);
            hmac.update(JSON.stringify(sortObject(requestBody)));
            const signature = hmac.digest('hex');

            if (nowPaymentsSignature !== signature) {
                logger.error("HMAC signature mismatch" + JSON.stringify({ ...requestHeaders, nowPaymentsSignature, signature }));

                return res.status(500).json({ error: "Internal server error" });
            }

            // * Process webhook request (payment failed, finished, expired, etc.)
            await processNPWebhookEvent(requestBody);

            // res.send();
        } catch (e) {
            logger.error("[NowPaymentsController.handleWebhook] \n" + (e));

            res.status(500).json({ error: "Internal server error" });
        }
    },


}

// TODO: Move into another file ?
/**
 * Used to sort request body in order (alphabetic?), before generating HMAC signature
 * 
 * @param {*} obj 
 * @returns 
 */
const sortObject = (obj) => {
    return Object.keys(obj).sort().reduce(
        (result, key) => {
            result[key] = (obj[key] && typeof obj[key] === 'object') ? sortObject(obj[key]) : obj[key]
            return result
        },
        {}
    )
}