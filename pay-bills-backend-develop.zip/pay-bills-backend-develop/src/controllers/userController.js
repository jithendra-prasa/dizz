export const userController = {
  getCurrentUser: async (req, res) => {
    try {
      const { password, createdAt, updatedAt, ...user } = req.user;
      res.json(user);
    } catch (e) {
      res.status(401).json({ error: "Not logged in" }); //todo replace with middleware
    }
  },
};
