// @ts-check

import express from "express";
import { config } from "dotenv";
import { essentialMiddleware } from "./middleware/essentialsMiddleware.js";
import { paymentsRoutes } from "./routes/paymentsRoutes.js";
import session from "express-session";
import passport from "passport";
import "./auth-strategies/local-strategy.js";
import { PrismaSessionStore } from "@quixo3/prisma-session-store";
import { PrismaClient } from "@prisma/client";
import { authRoutes } from "./routes/authRoutes.js";
import { userRoutes } from "./routes/userRoutes.js";
import { localisationMiddleware } from "./middleware/localisationMiddleware.js";
import CC from "currency-converter-lt";
import { loggingMiddleware } from "./middleware/loggingMiddleware.js";

import { insertCountriesIntoDB } from "./services/database/countries.js"
import { locationRoutes } from "./routes/locationRoutes.js"
import { orderSummaryRoutes } from "./routes/orderSummaryRoutes.js"
import { insertExchangeRatesIntoDB } from "./services/database/currencyExchangeRates.js";
import { scheduleExchangeRatesUpdate } from "./services/schedules/exchangeRateSchedule.js";
import { insertMomoProvidersIntoDB } from "./services/database/momo_providers.js";
import { momoRoutes } from "./routes/momoRoutes.js";
import { calculationRoutes } from "./routes/amountFeesRoutes.js";
import logger from "./utils/logger.js";

config();
export const prisma = new PrismaClient();

export let currencyConverter = new CC();
const currencyRatesCacheOptions = {
  isRatesCaching: true, // Set this boolean to true to implement rate caching
  ratesCacheDuration: 3600, // Set this to a positive number to set the number of seconds you want the rates to be cached. Defaults to 3600 seconds (1 hour)
};
currencyConverter = currencyConverter.setupRatesCache(
  currencyRatesCacheOptions
);

const port = process.env.API_PORT;
const app = express();

app.use(essentialMiddleware);
app.use(localisationMiddleware);
app.use(loggingMiddleware);
app.use(
  session({
    secret: "fgdfg&^%*(*&jkllouykmn878545ghkj&^",
    saveUninitialized: false,
    resave: false,
    cookie: {
      maxAge: 365.25 * 24 * 60 * 60 * 1000,
    },
    store: new PrismaSessionStore(new PrismaClient(), {
      checkPeriod: 2 * 60 * 1000, //ms
      dbRecordIdIsSessionId: true,
      dbRecordIdFunction: undefined,
    }),
  })
);

app.use(passport.initialize());
app.use(passport.session());

app.use("/payments", paymentsRoutes);
app.use("/auth", authRoutes);
app.use("/user", userRoutes);

// Methods to insert data into the database
// Countries insertion
await insertCountriesIntoDB();

// Mobile money providers insertion
await insertMomoProvidersIntoDB();

// Exchange rates insertion
await insertExchangeRatesIntoDB();

// Schedule exchange rates update
scheduleExchangeRatesUpdate();

app.use("/location", locationRoutes);
app.use("/orderSummary", orderSummaryRoutes);
app.use("/momo", momoRoutes);
app.use("/calculations", calculationRoutes);

// * Global error handlers
// Should prevent app from crashing when throwing errors
process.on('uncaughtException', (err) => {
  logger.error("Uncaught Exception: \n" + (err));

  // process.exit(1); // Optionally shut down
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error("Unhandled Rejection: \n" + (reason));
});

app.listen(port, () => {
  console.log(`API server started on port ${port}`);
});
