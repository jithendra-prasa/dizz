export const CreateQueryString = (queryParamsObj) => {
  return Object.keys(queryParamsObj)
    .map((key) => `${key}=${queryParamsObj[key]}`)
    .join(`&`);
};
