/**
 * Compares two dates based on day, month, and year, ignoring the time
 * @param {Date} date1 
 * @param {Date} date2 
 * @returns 1 => date1 > date2
 * @returns 0 => date1 === date2
 * @returns -1 => date1 < date2
 */
export const compareDates = (date1, date2) => {
    // Extract the day, month, and year for both dates
    const d1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    const d2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());

    // Compare the two dates
    if (d1.getTime() === d2.getTime()) {
        return 0; // Dates are equal
    } else if (d1.getTime() < d2.getTime()) {
        return -1; // date1 is earlier than date2
    } else {
        return 1; // date1 is later than date2
    }
}