import winston from "winston";
const { createLogger, format, transports } = winston;
const { combine, timestamp, printf, errors } = format;

// Define a custom log format
const customFormat = printf(({ level, message, timestamp, stack }) => {
  return `${timestamp} [${level}] ${stack || message}`;
});

const logger = createLogger({
  level: "info", // default log level
  format: combine(
    timestamp(),
    errors({ stack: true }), // log stack trace if error
    customFormat
  ),
  transports: [
    new transports.Console(), // logs to console
    new transports.File({ filename: "logs/error.log", level: "error" }), // error logs
    new transports.File({ filename: "logs/combined.log" }), // combined logs
  ],
});

export default logger;
