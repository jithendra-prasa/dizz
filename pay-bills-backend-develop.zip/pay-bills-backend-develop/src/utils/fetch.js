import logger from "./logger.js";

export async function getData(url, accsessToken) {
  //  try {
  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accsessToken}`,
      "Cache-Control": "no-cache",
    },
  });

  if (!response.ok) {
    const errBody = await response.json();
    console.log(errBody);
    logger.error(
      `[OUTBOUND Get Rquest Error] - [${response.status}] - ${JSON.stringify({
        resBody: errBody,
      })}`
    );
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const jsonResponse = await response.json();
  return jsonResponse;
  // } catch (e) {
  //   throw new Error("Error when making the get request: ", e);
  // }
}

export async function postData(url, data = {}, accsessToken = "") {
  // try {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accsessToken}`,
      "Cache-Control": "no-cache",
      "User-Agent": "PostmanRuntime/7.41.0",
      Connection: "keep-alive",
      Accept: "*/*",
      "Accept-Encoding": "gzip, deflate, br",
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const errBody = await response.json();
    console.log(errBody);
    logger.error(
      `[OUTBOUND Post Request Error] - [${response.status}] - ${JSON.stringify({
        resBody: errBody,
      })}`
    );
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const jsonResponse = await response.json();
  return jsonResponse;
  // } catch (e) {
  //   throw new Error("Error when making the post request: ", e);
  // }
}
