import geoip from "geoip-lite";
import "dotenv/config";
import logger from "./logger.js";

export const getIpInfo = function (ip) {
  // IPV6 addresses can include IPV4 addresses
  // So req.ip can be '::ffff:86.3.182.58'
  // However geoip-lite returns null for these
  if (ip.includes("::ffff:")) {
    ip = ip.split(":").reverse()[0];
  }

  let lookedUpIP = geoip.lookup(ip);

  if (ip === "127.0.0.1" || ip === "::1") {
    const testIp = "178.238.11.6";

    //178.238.11.6 - uk
    //170.171.1.0 - USA
    //176.31.84.249 - France

    lookedUpIP = geoip.lookup(testIp);
    return {
      error:
        "This won't work on localhost, Assuming this is in a testing envoroment returning the test IP",
      ...lookedUpIP,
    };
  }
  if (!lookedUpIP) {
    logger.error("Unable to get ip info for ip address " + ip);
    return { error: "Error occured while trying to process the information" };
  }
  return lookedUpIP;
};
