// @ts-check

import axios from "axios";
import axiosRetry from "axios-retry";
import logger from "./logger.js";


export const axiosInstance = axios.create({
    // baseURL: "https://api.example.com",
    timeout: 5000, // 5 seconds timeout
    headers: {
        "Content-Type": "application/json",
    },
});

// Enable Retry on failure
axiosRetry(axiosInstance, {
    retries: 3, // Retry up to 3 times
    retryDelay: (retryCount) => {
        logger.warn(`Retry attempt: ${retryCount}`);

        return retryCount * 1000; // Incremental backoff
    },
    // retryCondition: (error) => (error.response?.status && error.response?.status >= 500), // Retry only on server errors
});

// Request Interceptor
axiosInstance.interceptors.request.use(
    (config) => {
        logger.info(`Request: ${config.method?.toUpperCase()} ${config.url}`);

        return config;
    },
    (error) => {
        logger.error("Request Error:", error);

        return Promise.reject(error);
    }
);

// Response Interceptor
axiosInstance.interceptors.response.use(
    (response) => {
        logger.info(`Response: ${response.status} ${response.config.url}`);

        return response;
    },
    (error) => {
        logger.error("Response Error:", error.response?.status, error.message);

        return Promise.reject(error);
    }
);


