import { getCurrency } from "country-currency-map-2";
import { currencyConverter } from "../server.js";
import logger from "./logger.js";
import { calculateExchangeRateFromTo, convertAmountCurrency } from "../services/currencies/converter.js";

//this whole file needs cleaned up, was rushed to meet deadlines

// TODO: Useless now. Remove ?
export function calculateAmoutWithFee(amount, persentage, fixedAmmount, rate) {
  persentage = persentage / 100;
  amount = parseFloat(amount);

  const fixedAmmountInUsersCurrency = parseFloat(
    convertCurrency(fixedAmmount, rate)
  );

  return parseFloat(
    (amount * persentage + amount + fixedAmmountInUsersCurrency).toFixed(2)
  );
}

export function convertCurrency(ammount, rate) {
  return (ammount * rate).toFixed(2);
}

export async function GetCurrentExhnageRate(currencyFrom, currencyTo) {
  console.log(currencyFrom, currencyTo);
  let newValue = 0;
  if (currencyFrom === currencyTo) return 1;
  try {

    const fxRate = await calculateExchangeRateFromTo(currencyFrom, currencyTo)

    console.log({ fxRate });

    newValue = fxRate.exchangeRate;

    // ! Would systematically return 'NaN' 
    // newValue = await currencyConverter
    //   .from(currencyFrom)
    //   .to(currencyTo)
    //   .amount(1)
    //   .convert();

    console.log("rate (not rounded): " + newValue);
    return parseFloat(newValue);
  } catch (error) {
    logger.error(
      `[GetCurrentExhnageRate] prams: ${JSON.stringify({
        currencyFrom,
        currencyTo,
      })} error: ${JSON.stringify(error)} `
    );
    console.error("Error during conversion:", error);
    throw error;
  }
}

export async function ConvertAirtimeOperatorsCurrencys(
  operators,
  targetCurrency
) {
  try {
    const exhangeRateForCurrencyPair = await GetCurrentExhnageRate(
      operators[0].senderCurrencyCode,
      targetCurrency
    );

    // Map over the array and process each object
    const convertedObjects = operators.map((operator) => {
      // Process each fixedAmountsDescriptions property in the object
      const entries = Object.entries(operator.fixedAmountsDescriptions);

      // Map over the entries and update each key
      const updatedEntries = entries.map(([key, value]) => {
        const keyWithConvertedCurrency = convertCurrency(
          parseFloat(key),
          exhangeRateForCurrencyPair
        );

        // ! DEPRECATED
        // const keyWithOurFeeInUsersC = calculateAmoutWithFee(
        //   keyWithConvertedCurrency,
        //   20,
        //   0.75,
        //   exhangeRateForCurrencyPair
        // ); //this is a 20 percent & a 0.75 fee this needs to be pulled from mysql or something in future
        // return [keyWithOurFeeInUsersC.toFixed(2), value];

        const keyInUsersC = parseFloat(keyWithConvertedCurrency);

        return [keyInUsersC.toFixed(2), value];
      });
      // Convert the array of updated entries back into an object
      const updatedFixedAmountsDescriptions =
        Object.fromEntries(updatedEntries);

      // TODO: do with fees too ?
      const minAmountInUserC = convertCurrency(
        operator.minAmount,
        exhangeRateForCurrencyPair
      );

      const maxAmountInUserC = convertCurrency(
        operator.maxAmount,
        exhangeRateForCurrencyPair
      );

      // Return a new object with the updated fixedAmountsDescriptions
      return {
        ...operator,
        fixedAmountsDescriptions: updatedFixedAmountsDescriptions,
        usersCurrencySymbol: getCurrency(targetCurrency).symbolFormat,
        fees: {
          ...operator.fees,
          international: parseFloat(
            convertCurrency(
              operator.fees.international,
              exhangeRateForCurrencyPair
            )
          ),
        },

        minAmountInUserC,
        maxAmountInUserC,
      };
    });

    // Return the new array with all objects updated
    return convertedObjects;
  } catch (e) {
    logger.error(
      `[ConvertAirtimeOperatorsCurrencys] prams: ${JSON.stringify({
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}

export async function ConvertAirtimeOperatorByIDCurrency(
  operator,
  targetCurrency
) {
  try {
    // Get the exchange rate for the currency pair
    const exchangeRateForCurrencyPair = await GetCurrentExhnageRate(
      operator.senderCurrencyCode,
      targetCurrency
    );

    // Process each fixedAmountsDescriptions property in the object
    const entries = Object.entries(operator.fixedAmountsDescriptions);

    // Map over the entries and update each key
    const updatedEntries = entries.map(([key, value]) => {
      const keyWithConvertedCurrency = convertCurrency(
        parseFloat(key),
        exchangeRateForCurrencyPair
      );

      // ! DEPRECATED
      // const keyWithOurFeeInUsersC = calculateAmoutWithFee(
      //   keyWithConvertedCurrency,
      //   20,
      //   0.75,
      //   exchangeRateForCurrencyPair
      // ); //this is a 20 percent & a 0.75 fee this needs to be pulled from mysql or something in future
      // return [keyWithOurFeeInUsersC.toFixed(2), value];

      const keyInUserC = parseFloat(keyWithConvertedCurrency);

      return [keyInUserC.toFixed(2), value];
    });

    // Convert the array of updated entries back into an object
    const updatedFixedAmountsDescriptions = Object.fromEntries(updatedEntries);

    // Return a new object with the updated fixedAmountsDescriptions
    return {
      ...operator,
      fixedAmountsDescriptions: updatedFixedAmountsDescriptions,
      fees: {
        ...operator.fees,
        international: parseFloat(
          convertCurrency(
            operator.fees.international,
            exchangeRateForCurrencyPair
          )
        ),
        internationalInOurReloadlyCurrrency: operator.fees.international,
      },
    };
  } catch (e) {
    logger.error(
      `[ConvertAirtimeOperatorByIDCurrency] prams: ${JSON.stringify({
        operator,
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}

export async function ConvertCardsCurrencys(cards, targetCurrency) {
  try {
    const exhangeRateForCurrencyPair = await GetCurrentExhnageRate(
      cards[0].senderCurrencyCode,
      targetCurrency
    );

    // Map over the array and process each object
    const convertedObjectsPromises = cards.map(async (card) => {
      // Map over the entries and update each key

      let convertedFixedPricesWithOurFees = null;
      let convertedRangedPrices = null;
      let convertedRecipientRangedPrices = null;

      if (card.denominationType === "FIXED") {
        convertedFixedPricesWithOurFees = card.fixedSenderDenominations.map(
          (value) => {
            const ammountInUsersC = convertCurrency(
              value,
              exhangeRateForCurrencyPair
            );

            // ! DEPRECATED
            // const ammountInUserCWithOurFees = calculateAmoutWithFee(
            //   ammountInUsersC,
            //   20,
            //   0.75,
            //   exhangeRateForCurrencyPair
            // );

            // return ammountInUserCWithOurFees;

            return parseFloat(ammountInUsersC);
          }
        );
      } else if (card.denominationType === "RANGE") {
        convertedRangedPrices = {
          min: parseFloat(
            convertCurrency(
              card.minSenderDenomination,
              exhangeRateForCurrencyPair
            )
          ),
          max: parseFloat(
            convertCurrency(
              card.maxSenderDenomination,
              exhangeRateForCurrencyPair
            )
          ),
        };

        // * Recipent price min and max conversion
        const recipientCurrencyCode = cards[0].recipientCurrencyCode;

        const convertedMinData = await convertAmountCurrency(
          card.minRecipientDenomination,
          recipientCurrencyCode,
          targetCurrency
        );

        const convertedMaxData = await convertAmountCurrency(
          card.maxRecipientDenomination,
          recipientCurrencyCode,
          targetCurrency
        )

        convertedRecipientRangedPrices = {
          min: convertedMinData.convertedAmount,
          max: convertedMaxData.convertedAmount,
        };
      }

      // Return a new object with the updated fixedAmountsDescriptions
      return {
        ...card,
        fixedSenderDenominationsUserC: convertedFixedPricesWithOurFees || null,
        fixedSenderDenominationsOurC: card.fixedSenderDenominations || null,

        minSenderDenominationUserC: convertedRangedPrices
          ? convertedRangedPrices.min
          : null,
        maxSenderDenominationUserC: convertedRangedPrices
          ? convertedRangedPrices.max
          : null,

        minSenderDenominationOurC: convertedRangedPrices
          ? card.minSenderDenomination
          : null,
        maxSenderDenominationOurC: convertedRangedPrices
          ? card.maxSenderDenomination
          : null,

        // Recipient 
        minRecipientDenominationUserC: convertedRecipientRangedPrices
          ? convertedRecipientRangedPrices.min
          : null,
        maxRecipientDenominationUserC: convertedRecipientRangedPrices
          ? convertedRecipientRangedPrices.max
          : null,

        minRecipientDenominationOurC: convertedRecipientRangedPrices
          ? card.minRecipientDenomination
          : null,
        maxRecipientDenominationOurC: convertedRecipientRangedPrices
          ? card.maxRecipientDenomination
          : null,

        senderFeeUserC: parseFloat(
          convertCurrency(card.senderFee, exhangeRateForCurrencyPair)
        ),
        senderFreeOurC: card.senderFee,

        usersCurrencySymbol: getCurrency(targetCurrency).symbolFormat,
      };
    });


    const convertedObjects = await Promise.all(convertedObjectsPromises);

    // Return the new array with all objects updated
    return convertedObjects;
  } catch (e) {
    logger.error(
      `[ConvertCardsCurrencys] prams: ${JSON.stringify({
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}

export async function ConvertCardBYIDCurrencys(card, targetCurrency) {
  try {
    const exhangeRateForCurrencyPair = await GetCurrentExhnageRate(
      card.senderCurrencyCode,
      targetCurrency
    );

    // Map over the entries and update each key
    let convertedFixedPricesWithOurFees = null;
    let convertedRangedPrices = null;
    let convertedRecipientRangedPrices = null;

    if (card.denominationType === "FIXED") {
      convertedFixedPricesWithOurFees = card.fixedSenderDenominations.map(
        (value) => {
          const ammountInUsersC = convertCurrency(
            value,
            exhangeRateForCurrencyPair
          );

          // ! DEPRECATED
          // const ammountInUserCWithOurFees = calculateAmoutWithFee(
          //   ammountInUsersC,
          //   20,
          //   0.75,
          //   exhangeRateForCurrencyPair
          // );

          // return ammountInUserCWithOurFees;

          return parseFloat(ammountInUsersC);
        }
      );
    } else if (card.denominationType === "RANGE") {
      convertedRangedPrices = {
        min: parseFloat(
          convertCurrency(
            card.minSenderDenomination,
            exhangeRateForCurrencyPair
          )
        ),
        max: parseFloat(
          convertCurrency(
            card.maxSenderDenomination,
            exhangeRateForCurrencyPair
          )
        ),
      };

      // * Recipent price min and max conversion
      const recipientCurrencyCode = card.recipientCurrencyCode;

      const convertedMinData = await convertAmountCurrency(
        card.minRecipientDenomination,
        recipientCurrencyCode,
        targetCurrency
      );

      const convertedMaxData = await convertAmountCurrency(
        card.maxRecipientDenomination,
        recipientCurrencyCode,
        targetCurrency
      )

      convertedRecipientRangedPrices = {
        min: convertedMinData.convertedAmount,
        max: convertedMaxData.convertedAmount,
      };
    }

    // Return a new object with the updated fixedAmountsDescriptions
    return {
      ...card,
      fixedSenderDenominationsUserC: convertedFixedPricesWithOurFees || null,
      fixedSenderDenominationsOurC: card.fixedSenderDenominations || null,

      minSenderDenominationUserC: convertedRangedPrices
        ? convertedRangedPrices.min
        : null,
      maxSenderDenominationUserC: convertedRangedPrices
        ? convertedRangedPrices.max
        : null,

      minSenderDenominationOurC: convertedRangedPrices
        ? card.minSenderDenomination
        : null,
      maxSenderDenominationOurC: convertedRangedPrices
        ? card.maxSenderDenomination
        : null,

      // Recipient 
      minRecipientDenominationUserC: convertedRecipientRangedPrices
        ? convertedRecipientRangedPrices.min
        : null,
      maxRecipientDenominationUserC: convertedRecipientRangedPrices
        ? convertedRecipientRangedPrices.max
        : null,

      minRecipientDenominationOurC: convertedRecipientRangedPrices
        ? card.minRecipientDenomination
        : null,
      maxRecipientDenominationOurC: convertedRecipientRangedPrices
        ? card.maxRecipientDenomination
        : null,

      senderFeeUserC: parseFloat(
        convertCurrency(card.senderFee, exhangeRateForCurrencyPair)
      ),
      senderFreeOurC: card.senderFee,

      usersCurrencySymbol: getCurrency(targetCurrency).symbolFormat,
    };
  } catch (e) {
    logger.error(
      `[ConvertCardBYIDCurrencys] prams: ${JSON.stringify({
        card,
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}

// todo giftcard by ID

export async function ConvertUtilitySuppliersCurrencys(
  billers,
  targetCurrency
) {
  try {
    const exhangeRateForCurrencyPair = await GetCurrentExhnageRate(
      billers[0].internationalTransactionCurrencyCode,
      targetCurrency
    );

    // Map over the array and process each object
    const convertedObjects = billers.map((biller) => {
      // Map over the entries and update each key

      let convertedFixedPrices = null;
      let convertedRangedPrices = null;
      if (biller.denominationType === "FIXED") {
        convertedFixedPrices = [];
        convertedFixedPrices = biller.internationalFixedAmounts.map((value) => {
          return convertedFixedPrices.push(value); //todo MAKE FIXED  VALUES WORK
        });
      } else if (biller.denominationType === "RANGE") {
        convertedRangedPrices = {
          //todo in future
          min: null,
          max: null,
        };
      }

      // Return a new object with the updated fixedAmountsDescriptions
      return {
        ...biller,
        //   fixedSenderDenominationsUserC: convertedFixedPrices || null,
        //   fixedSenderDenominationsOurC: biller.fixedSenderDenominations || null,

        //   minSenderDenominationUserC: convertedRangedPrices
        //     ? convertedRangedPrices.min
        //     : null,
        //   maxSenderDenominationUserC: convertedRangedPrices
        //     ? convertedRangedPrices.max
        //     : null,

        //   minSenderDenominationOurC: convertedRangedPrices
        //     ? biller.minSenderDenomination
        //     : null,
        //   maxSenderDenominationOurC: convertedRangedPrices
        //     ? biller.maxSenderDenomination
        //     : null,

        senderFeeUserC: parseFloat(
          convertCurrency(
            biller.internationalTransactionFee,
            exhangeRateForCurrencyPair
          )
        ),
        senderFreeOurC: biller.internationalTransactionFee,
        userCurrency: targetCurrency,
      };
    });

    // Return the new array with all objects updated
    return convertedObjects;
  } catch (e) {
    logger.error(
      `[ConvertUtilitySuppliersCurrencys] prams: ${JSON.stringify({
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}

export async function ConvertUtilitySupplierBYIDCurrency(
  supplier,
  targetCurrency
) {
  try {
    // Get the exchange rate for the currency pair
    const exchangeRateForCurrencyPair = await GetCurrentExhnageRate(
      supplier.localTransactionCurrencyCode,
      targetCurrency
    );

    // Initialize converted price variables
    let convertedFixedPrices = null;
    let convertedRangedPrices = null;

    // Check the denomination type and process accordingly
    if (supplier.denominationType === "FIXED") {
      convertedFixedPrices = [];
      convertedFixedPrices = supplier.internationalFixedAmounts.map((value) => {
        // You can include conversion logic here if needed
        return convertedFixedPrices.push(value); // todo: MAKE FIXED VALUES WORK
      });
    } else if (supplier.denominationType === "RANGE") {
      convertedRangedPrices = {
        // todo: Implement conversion logic for ranged prices in the future
        min: null,
        max: null,
      };
    }

    // Return a new object with updated properties
    return {
      ...supplier,
      // Uncomment and update these fields as per your requirement
      // fixedSenderDenominationsUserC: convertedFixedPrices || null,
      // fixedSenderDenominationsOurC: supplier.fixedSenderDenominations || null,

      // minSenderDenominationUserC: convertedRangedPrices
      //   ? convertedRangedPrices.min
      //   : null,
      // maxSenderDenominationUserC: convertedRangedPrices
      //   ? convertedRangedPrices.max
      //   : null,

      // minSenderDenominationOurC: convertedRangedPrices
      //   ? supplier.minSenderDenomination
      //   : null,
      // maxSenderDenominationOurC: convertedRangedPrices
      //   ? supplier.maxSenderDenomination
      //   : null,

      senderFeeUserC: parseFloat(
        convertCurrency(
          supplier.internationalTransactionFee,
          exchangeRateForCurrencyPair
        )
      ),
      senderFreeOurC: supplier.internationalTransactionFee,
      userCurrency: targetCurrency,
    };
  } catch (e) {
    logger.error(
      `[ConvertUtilitySupplierBYIDCurrency] prams: ${JSON.stringify({
        supplier,
        targetCurrency,
      })} error: ${JSON.stringify(e)}`
    );
    throw e;
  }
}
