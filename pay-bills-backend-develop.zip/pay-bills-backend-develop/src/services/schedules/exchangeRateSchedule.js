import schedule from 'node-schedule';
import { insertExchangeRatesIntoDB } from '../database/currencyExchangeRates.js';

/**
 * Schedule periodic updates (daily at midnight by default) of currency exchange rates
 */
export const scheduleExchangeRatesUpdate = () => {
    // Job scheduled for midnight
    // '0 0 * * *' -> cron syntax
    schedule.scheduleJob('0 0 * * *', insertExchangeRatesIntoDB);
    
    //TODO: Look for a way to check if job was successful or not. Retry if not successful.
} 