//@ts-check

import { z, ZodError } from "zod";
import { prisma } from "../../server.js";
import logger from "../../utils/logger.js";


const countryIso2Schema = z
    .string()
    .nonempty({ message: "Country ISO2 code is required" });

/**
 * Retrieves supported Mobile Money operators for a specific country.
 * 
 * 
 * @async
 * 
 * @param {string} countryIso2 - Country ISO code (2 letters)
 * 
 * @returns {Promise<Array<{
 *   countryIso2: string,
 *   countryIso3: string,
 *   countryInfo: {
 *     name: string,
 *     currencies: Array<{name: string}>,
 *     callingCodes: Array<{code: string}>
 *   },
 *   supportedOperators: Array<{
 *     name: string,
 *     momoName: string
 *   }>
 * }>>} Array of objects containing country information and supported operators, or empty array if none found
 * 
 * @throws {Error} If the operation fails to check MoMo availability
 * @throws {ZodError} If the argument validation fails
 */
export const getSupportedMoMoOperatorsByCountry = async (/** @type {string} */ countryIso2) => {
    try {
        const parsedCountryIso2 = countryIso2Schema.parse(countryIso2);

        const supportedOperatorsInfo = await prisma.momoCountry.findMany({
            where: {
                countryIso2: parsedCountryIso2.toUpperCase(),
            },
            select: {
                // id: true,
                countryIso2: true,
                countryIso3: true,
                countryInfo: {
                    select: {
                        // id: true,
                        name: true,
                        // isoCode: true,
                        currencies: {
                            select: {
                                name: true,
                            }
                        },
                        callingCodes: {
                            select: {
                                code: true
                            }
                        },
                    }
                },
                supportedOperators: {
                    where: {
                        status: true
                    },
                    select: {
                        // id: true,
                        name: true,
                        momoName: true,
                    }
                },
            },
            orderBy: {
                countryInfo: {
                    name: "asc"
                },
            },
        });

        return supportedOperatorsInfo;
    } catch (error) {
        logger.error("[checkCountryMoMoAvailability] \n" + (error));

        console.error("Error checking MoMo availability:", error);

        throw new Error("Failed to check MoMo availability");
    }
}