//@ts-check

import { z } from "zod";
import { axiosInstance } from "../../utils/axiosInstance.js";
import logger from "../../utils/logger.js";
import { NOW_PAYMENTS_TRANSACTION_CURRENCY } from "../../constants/nowPaymentsConstants.js";
import { convertAmountCurrency } from "../currencies/converter.js";
import { NPInvoiceSchema } from "../../models/nowPaymentsSchema.js";

const nowPaymentsUrl = process.env.NOW_PAYMENTS_BASE_URL;
const nowPaymentsApiKey = process.env.NOW_PAYMENTS_API_KEY;
const nowPaymentsCallbackUrl = process.env.NOW_PAYMENTS_CALLBACK_URL;
const successUrl = process.env.PAYMENT_SUCCESS_URL;
const cancelUrl = process.env.PAYMENT_CANCEL_URL;

/**
 * Used to generate NOWPayments crypto payment invoice URL
 * 
 * @param {z.infer<typeof NPInvoiceSchema>} invoice 
 * 
 * @returns {Promise<{invoice_url: string}>}
 */
export const createInvoice = async ( /** @type {z.infer<typeof NPInvoiceSchema>} */ invoice) => {
    try {
        NPInvoiceSchema.parse(invoice);

        const finalInvoice = {
            ...invoice,
            ipn_callback_url: nowPaymentsCallbackUrl,
            success_url: successUrl,
            cancel_url: cancelUrl,
        }

        const response = await axiosInstance.post(nowPaymentsUrl + "/invoice", finalInvoice, {
            headers: {
                "x-api-key": nowPaymentsApiKey
            }
        });

        console.log("NOWPayments Invoice response data", response.data);

        return response.data;
    } catch (error) {
        logger.error(
            `[createInvoice]
             error: ${error}`
        );

        throw new Error(`Failed to create NOW Payments invoice: ${error}`);
    }
};

/**
 * Function to convert a specified `amount` to NOWPayments transaction currency (arbitrary)
 * 
 * @param {number} amount The amount to convert
 * @param {string} amountCurrency The currency (3-character ISO code) of the amount
 */
export const convertAmountToNPCurrency = async (amount, amountCurrency) => {
    const convertedAmountData = await convertAmountCurrency(amount, amountCurrency, NOW_PAYMENTS_TRANSACTION_CURRENCY);

    return convertedAmountData;
}