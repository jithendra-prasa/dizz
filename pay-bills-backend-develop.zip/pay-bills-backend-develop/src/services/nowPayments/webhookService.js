// @ts-check

import { z } from "zod";
import { NPWebhookResponseSchema } from "../../models/nowPaymentsSchema.js";
import { updateOrderSummaryStatusByOrderId } from "../database/orderSummary.js";
import { ProcessReloadlyOrder } from "../reloadly/processOrder.js";
import { emailOrderSummary } from "../email/emailOrderSummary.js";
import { createTransaction } from "../database/transaction.js";
import logger from "../../utils/logger.js";
import { ordersDatabaseService } from "../database/orders.js";

/**
 * Processes NOWPayments webhook events
 * 
 * Uses payment status (failed, finished, expired, etc.) to update order status in DB and also trigger Reloadly order
 * 
 * @param {z.infer<typeof NPWebhookResponseSchema>} eventData 
 */
export const processNPWebhookEvent = async (/** @type {z.infer<typeof NPWebhookResponseSchema>} */ eventData) => {
    try {
        const orderId = eventData.order_id;

        if (!orderId) {
            const errorMessage = "NOWPayments Webhook event - orderId is null - CANNOT UPDATE ORDER\n"
                + "paymentId = " + eventData.payment_id;

            logger.error(errorMessage);

            throw new Error(errorMessage)
        }

        switch (eventData.payment_status) {
            case "confirming":

                const pendingOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    pendingOrderDetailsOrderId,
                    "Processing"
                );

                updateOrderSummaryStatusByOrderId(pendingOrderDetailsOrderId, "PENDING")

                logger.info("confirming", orderId);

                break;

            case "finished":

                const completedOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    completedOrderDetailsOrderId,
                    "Payment Recived"
                );

                updateOrderSummaryStatusByOrderId(completedOrderDetailsOrderId, "PAID")

                await ProcessReloadlyOrder(completedOrderDetailsOrderId);

                emailOrderSummary(completedOrderDetailsOrderId);

                createTransaction({
                    orderId: completedOrderDetailsOrderId,
                    amountPaid: eventData.price_amount,
                    currencyCode: eventData.price_currency,
                    cryptoTxNumber: eventData.payment_id.toString(),
                    stripeTxNumber: null,
                    mobileMoneyTxNumber: null,
                });

                logger.info("finished", orderId);

                break;

            case "failed":

                const failedOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    failedOrderDetailsOrderId,
                    "Payment Failed"
                );

                updateOrderSummaryStatusByOrderId(failedOrderDetailsOrderId, "FAILED")

                logger.info("failed", orderId);

                break;

            case "expired":

                const expiredOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    expiredOrderDetailsOrderId,
                    "Checkout Expired"
                );

                updateOrderSummaryStatusByOrderId(expiredOrderDetailsOrderId, "CANCELLED")

                logger.info("expired", orderId);

                break;
        }
    } catch (error) {
        throw error;
    }
}