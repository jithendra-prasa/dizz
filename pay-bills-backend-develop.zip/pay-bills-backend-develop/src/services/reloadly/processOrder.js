import { ordersDatabaseService } from "../database/orders.js";
import { reloadlyUtilityService } from "./utilityService.js";
import { reloadlyAirtimeService } from "./airtimeService.js";
import { reloadlyGiftCardService } from "./giftCardService.js";

import { updateOrderSummaryRedeemCode } from "../database/orderSummary.js"

export const ProcessReloadlyOrder = async (orderId) => {
  const orderDetails = await ordersDatabaseService.GetOrderDetails(orderId);

  console.log(orderDetails);

  switch (orderDetails.service) {
    case "Pay Utility":
      const utilityBillDetails = orderDetails.items[0]; //this will be fine for now. this will brake if we ever add a shopping cart feature for pay bills, but i dont see that being needed
      const reloadlyRequestData = {
        subscriberAccountNumber: utilityBillDetails.subscriberAccountNumber,
        amount: utilityBillDetails.AmmountWithoutFeesInOurC,
        useLocalAmount: false,
        billerId: utilityBillDetails.billerId,
      };

      //   console.log(reloadlyRequestData);

      const reloadlyReponce = await reloadlyUtilityService.PayBill(
        reloadlyRequestData
      );

      console.log(reloadlyReponce);

      ordersDatabaseService.UpdateVendorFields(
        orderId, //TODO orders will remain as processing for now, maybes use a cron job to fetch upto date data for orders where vender status is pending
        reloadlyReponce.id,
        reloadlyReponce.status,
        reloadlyReponce
      );
      break;

    case "Airtime":
      const airtimeDetails = orderDetails.items[0];
      const airtimeRequestData = {
        // Fill in the required fields for airtime recharge
        recipientPhone: {
          number: airtimeDetails.recipientPhone,
          countryCode: airtimeDetails.recipientcountryCode,
        },
        amount: airtimeDetails.AmmountWithoutFeesOurC,
        operatorId: airtimeDetails.operatorId,
        // Add other necessary fields
      };

      const airtimeResponse = await reloadlyAirtimeService.SendTopup(
        airtimeRequestData
      );

      console.log(airtimeResponse);

      ordersDatabaseService.UpdateVendorFields(
        orderId,
        airtimeResponse.transactionId,
        airtimeResponse.status,
        airtimeResponse
      );
      break;

    case "GiftCard":
      const giftCardDetails = orderDetails.items[0];
      const giftCardRequestData = {
        // Fill in the required fields for giftCard
        unitPrice: giftCardDetails.ammountInCardVenderCurrency,
        productId: giftCardDetails.productId,
        quantity: giftCardDetails.quantity,
        senderName: giftCardDetails.benName,
        // Add other necessary fields
      };

      const giftCardResponse =
        await reloadlyGiftCardService.ProcessPayForGiftCard(
          giftCardRequestData
        );

      console.log(giftCardResponse);

      ordersDatabaseService.UpdateVendorFields(
        orderId,
        giftCardResponse.transactionId,
        giftCardResponse.status,
        giftCardResponse
      );

      const redeemCode = await reloadlyGiftCardService.GetRedeemCode(giftCardResponse.transactionId);

      await updateOrderSummaryRedeemCode(orderId, redeemCode[0].cardNumber, redeemCode[0].pinCode);

      break;

    //TODO Add other cases here for other services, ETC
  }
};
