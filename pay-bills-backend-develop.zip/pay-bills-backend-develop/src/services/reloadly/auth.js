import "dotenv/config";
import { postData } from "../../utils/fetch.js";
import logger from "../../utils/logger.js";

export const ReloadlyAuth = async (endpointURL) => {
  try {
    const url = "https://auth.reloadly.com/oauth/token";
    const data = {
      client_id: process.env.RELOADLY_API_CLIENT_ID,
      client_secret: process.env.RELOADLY_API_CLIENT_SECRET,
      grant_type: "client_credentials",
      audience: endpointURL,
    };
    const responce = await postData(url, data);
    const authToken = responce.access_token;

    return authToken;
  } catch (e) {
    logger.error(
      `[ReloadlyAuth] prams: ${JSON.stringify({
        endpointURL,
      })} error: ${JSON.stringify(e)}`
    );
    throw new Error("Error when retreving auth token from reloadly: " + e);
  }
};
