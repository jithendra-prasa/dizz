import "dotenv/config";
import { getData, postData } from "../../utils/fetch.js";
import { ReloadlyAuth } from "./auth.js";
import logger from "../../utils/logger.js";

const mode = process.env.MODE;
const baseUrl =
  mode === "PROD"
    ? "https://topups.reloadly.com/"
    : "https://topups-sandbox.reloadly.com/";

export const reloadlyAirtimeService = {
  placeholder: async () => {
    try {
      const codeHereToCallAPI =
        "local Reloadly airtime service has been reatched - this is just a test message";
      return codeHereToCallAPI;
    } catch (e) {
      throw new Error("Error" + e);
    }
  },

  // GetCountries: async () => {
  //   try {
  //     const authToken = await ReloadlyAuth(baseUrl);

  //     const reloadlyResonce = await getData(`${baseUrl}countries`, authToken);

  //     return reloadlyResonce;
  //   } catch (e) {
  //     throw new Error("Error fetching countries from reloay API: " + e);
  //   }
  // },

  GetOperators: async () => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(`${baseUrl}operators`, authToken);

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.GetBillers] prams: ${JSON.stringify(
          {}
        )} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error fetching operators from reloay API: " + e);
    }
  },

  GetOperatorById: async (operatorId) => {
    console.log(operatorId);
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await getData(
        `${baseUrl}operators/${operatorId}`,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.GetOperatorById] prams: ${JSON.stringify({
          operatorId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error fetching operator by ID from Reloadly API: " + e);
    }
  },

  GetOperatorByCountry: async (country) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await getData(
        `${baseUrl}operators/countries/${country}`,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.GetOperatorByCountry] prams: ${JSON.stringify({
          country,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error fetching operator by Country from Reloadly API: " + e
      );
    }
  },

  SendTopup: async (topupData) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await postData(
        `${baseUrl}topups`,
        topupData,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.SendTopup] prams: ${JSON.stringify({
          topupData,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error sending topup using Reloadly API: " + e);
    }
  },

  GetTransactionInfo: async (transactionId) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}topups/${transactionId}`,
        authToken
      );

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.GetTransactionInfo] prams: ${JSON.stringify({
          transactionId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when tying to find transaction info using reloadly API " + e
      );
    }
  },

  AutoDetectOperator: async (phoneNumber, countryCode) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}operators/auto-detect/phone/${phoneNumber}/countries/${countryCode}`,
        authToken
      );

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyAirtimeService.AutoDetectOperator] prams: ${JSON.stringify({
          phoneNumber,
          countryCode,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when tying to find phone operator info using reloadly API " + e
      );
    }
  },
};
