import "dotenv/config";
import { getData, postData } from "../../utils/fetch.js";
import { ReloadlyAuth } from "./auth.js";
import logger from "../../utils/logger.js";

const mode = process.env.MODE;
const baseUrl =
  mode === "PROD"
    ? "https://giftcards.reloadly.com/"
    : "https://giftcards-sandbox.reloadly.com/";

export const reloadlyGiftCardService = {
  placeholder: async () => {
    try {
      const codeHereToCallAPI =
        "local Reloadly giftcard service has been reatched - this is just a test message";
      return codeHereToCallAPI;
    } catch (e) {
      throw new Error("Error" + e);
    }
  },

  GetCardsByCountry: async (country) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await getData(
        `${baseUrl}countries/${country}/products`,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyGiftCardService.GetCardsByCountry] prams: ${JSON.stringify({
          country,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error fetching operator by Country from Reloadly API: " + e
      );
    }
  },

  ProcessPayForGiftCard: async (reqData) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await postData(
        `${baseUrl}orders`,
        reqData,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyGiftCardService.ProcessPayForGiftCard] prams: ${JSON.stringify(
          {
            reqData,
          }
        )} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error processing giftcard payment with relaodly API: " + e
      );
    }
  },

  GetGiftCardDetails: async (productId) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await getData(
        `${baseUrl}products/${productId}`,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyGiftCardService.GetGiftCardDetails] prams: ${JSON.stringify({
          productId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error fetching giftcardProduct by ID from Reloadly API: " + e
      );
    }
  },

  /**
   * redeemCode structure => 
   * [{ cardNumber: "hUl1Dtest", pinCode: "10232test" }]
   */
  GetRedeemCode: async (transactionId) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);
      const reloadlyResponse = await getData(
        `${baseUrl}orders/transactions/${transactionId}/cards`,
        authToken
      );
      return reloadlyResponse;
    } catch (e) {
      logger.error(
        `[reloadlyGiftCardService.GetRedeemCode] prams: ${JSON.stringify(
          {
            transactionId,
          }
        )} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error getting gift card redeem code: " + e
      );
    }
  },
};
