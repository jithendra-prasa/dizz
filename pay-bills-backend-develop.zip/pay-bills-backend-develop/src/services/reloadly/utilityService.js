import "dotenv/config";
import { getData, postData } from "../../utils/fetch.js";
import { ReloadlyAuth } from "./auth.js";
import { StripeUtilityService } from "../stripe/utilityService.js";
import logger from "../../utils/logger.js";

const mode = process.env.MODE;
const baseUrl =
  mode === "PROD"
    ? "https://utilities.reloadly.com/"
    : "https://utilities-sandbox.reloadly.com/";

export const reloadlyUtilityService = {
  placeholder: async () => {
    try {
      const codeHereToCallAPI =
        "local Reloadly utility service has been reatched - this is just a test message";
      return codeHereToCallAPI;
    } catch (e) {
      throw new Error("Error" + e);
    }
  },

  GetBillers: async (query) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}billers?${query}`,
        authToken
      );

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyUtilityService.GetBillers] prams: ${JSON.stringify({
          query,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error when getting billers from reloadly API " + e);
    }
  },

  GetBillersByCountry: async (country) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}billers?countryISOCode=${country}`,
        authToken
      );

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyUtilityService.GetBillersByCountry] prams: ${JSON.stringify({
          country,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error when getting billers from reloadly API " + e);
    }
  },

  getBillerByID: async (id) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}billers?id=${id}`,
        authToken
      );

      const resWithSimpleType = {
        ...reloadlyResonce.content[0],
        simpleType:
          StripeUtilityService.billerTypes[reloadlyResonce.content[0].type] ||
          "Unknown",
      };

      return resWithSimpleType;
    } catch (e) {
      logger.error(
        `[reloadlyUtilityService.getBillerByID] prams: ${JSON.stringify({
          id,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error when getting biller from reloadly API " + e);
    }
  },

  PayBill: async (data) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await postData(`${baseUrl}pay`, data, authToken);

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyUtilityService.PayBill] prams: ${JSON.stringify({
          data,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error when paying a bill using reloadly API " + e);
    }
  },

  GetTransactionInfo: async (Tid) => {
    try {
      const authToken = await ReloadlyAuth(baseUrl);

      const reloadlyResonce = await getData(
        `${baseUrl}transactions/${Tid}`,
        authToken
      );

      return reloadlyResonce;
    } catch (e) {
      logger.error(
        `[reloadlyUtilityService.GetTransactionInfo] prams: ${JSON.stringify({
          Tid,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when tying to find transaction info using reloadly API " + e
      );
    }
  },
};
