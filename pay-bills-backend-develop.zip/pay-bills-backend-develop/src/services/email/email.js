import { createTransport } from "nodemailer";

const transporter = createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: process.env.EMAIL_PORT === "465" ? true : false, // true for port 465, false for other ports
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

export const emailTo = async ({ to, subject, text, html }) => {

    // send mail with defined transport object
    const info = await transporter.sendMail({
        from: process.env.EMAIL_USER, // '"Maddison Foo Koch 👻" <maddison53@ethereal.email>', // sender address
        to: to, // "bar@example.com, baz@example.com", // list of receivers
        subject: subject, // Subject line
        // Have to choose between html and text
        text: text, // plain text body
        html: html, // html body
    });

    console.log("Message sent: %s", info.messageId);
}

