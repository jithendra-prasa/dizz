
import { getOrderSummaryByOrderId } from "../database/orderSummary.js"
import { emailTo } from "./email.js"
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import handlebars from 'handlebars';
import logger from "../../utils/logger.js";

export const emailOrderSummary = async (orderId) => {
    try {
        const orderSummary = await getOrderSummaryByOrderId(orderId);

        const senderEmail = orderSummary.senderEmail;

        const benEmail = orderSummary?.benEmail;

        const html = await templateHtmlFile(orderSummary);

        await emailTo({
            to: `${senderEmail}, ${benEmail}`,
            subject: "DizzitUp - Order summary",
            // text: JSON.stringify(orderSummary, null, 2),
            html: html
        })
    } catch (e) {
        logger.error(
            `[emailOrderSummary] 
             error: ${(e)}`
        );
    }
}


const templateHtmlFile = async (orderSummary) => {
    // Resolve the directory of the current file
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);

    // Path to the email template
    const templatePath = path.join(__dirname, '..', '..', 'templates', 'orderSummary.html');

    // Load and compile the template
    const source = await fs.readFile(templatePath, 'utf8');
    const template = handlebars.compile(source);

    // Generate email content
    const html = template({
        // a web file would be better
        // logoUrl: "/dizzitup_logo.png",
        ...orderSummary
    });

    return html;
}