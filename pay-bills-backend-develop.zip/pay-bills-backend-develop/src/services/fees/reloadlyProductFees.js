
// @ts-check

import { AIRTIME, GIFT_CARD, UTILITY } from "../../constants/serviceTypeConstants.js";
import { reloadlyAirtimeService } from "../reloadly/airtimeService.js";
import { reloadlyGiftCardService } from "../reloadly/giftCardService.js";
import { reloadlyUtilityService } from "../reloadly/utilityService.js";

export const getReloadlyProductFees = async (/** @type {AIRTIME | GIFT_CARD | UTILITY} */ serviceType, /** @type {number} */ serviceProductId) => {

    try {

        let serivceFee = 0;
        let serviceFeeCurrency = "EUR";

        if (serviceType === AIRTIME) {
            const product = await reloadlyAirtimeService.GetOperatorById(
                serviceProductId
            );

            serivceFee = product.fees.international;
            serviceFeeCurrency = product.senderCurrencyCode;
        }

        if (serviceType === GIFT_CARD) {
            const product = await reloadlyGiftCardService.GetGiftCardDetails(
                serviceProductId
            );

            serivceFee = product.senderFee;
            serviceFeeCurrency = product.senderCurrencyCode;
        }

        if (serviceType === UTILITY) {
            const product = await reloadlyUtilityService.getBillerByID(
                serviceProductId
            );

            serivceFee = product.internationalTransactionFee;
            serviceFeeCurrency = product.internationalTransactionFeeCurrencyCode;
        }

        return { serivceFee, serviceFeeCurrency }
    } catch (error) {

    }


}