// @ts-check

import Decimal from "decimal.js";
import logger from "../../utils/logger.js";
import { convertAmountCurrency } from "../currencies/converter.js";
import { getFeesByCountry } from "../database/fees.js";
import { DEFAULT_DECIMAL_PLACES } from "../../constants/decimalConstants.js";

/**
 * Function to calculate fees based on the specified `amount`, `currency` and `countryIsoCode` and return the total amount (fees included)
 * 
 * The total amount is in the specified currency
 * @param {number} amount Base amount for the calculations
 * @param {string} currency The currency (3-character ISO code) of the amount. It is mostly used to convert the extra fee to the currency of the amount
 * @param {string} countryIsoCode 2 characters ISO code. Preferrably in uppercase. Used to fetch country-specific fees
 * @returns `totalFee` being the total calculated fee and `finalAmount` the addition of `baseAmount` and `totalFee`
 */
export const calculateAmountWithFees = async (amount, currency, countryIsoCode) => {
    try {
        // Getting country-specific fees
        const countryFees = await getFeesByCountry(countryIsoCode);

        const percentageFee = countryFees.fees.percentageFee;
        // TODO: Remove extra fee logic
        const extraFee = countryFees.fees.extraFee;
        const extraFeeCurrency = countryFees.fees.extraFeeCurrency;

        // Converting extra fee to the currency of the amount
        const convertedExtraFee = await convertAmountCurrency(extraFee, extraFeeCurrency, currency);

        // const totalFee = ((amount * (percentageFee / 100)) + convertedExtraFee.convertedAmount);
        // const finalAmount = amount + totalFee;

        const amountDecimal = new Decimal(amount);
        const percentageFeeDecimal = new Decimal(percentageFee);
        const extraFeeDecimal = new Decimal(convertedExtraFee.convertedAmount);

        // * => ((amount * (percentageFee / 100)) + convertedExtraFee.convertedAmount);
        const totalFeeDecimal = amountDecimal.times(percentageFeeDecimal).dividedBy(100)
            .plus(extraFeeDecimal);


        // * => amount + totalFee
        const finalAmountDecimal = amountDecimal.plus(totalFeeDecimal);

        const totalFee = totalFeeDecimal.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber();

        const finalAmount = finalAmountDecimal.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber();

        const amountWithFeesData = {
            baseAmount: amount,
            baseCurrency: currency,
            percentageFee,
            extraFee: convertedExtraFee.convertedAmount,
            totalFee,
            feeCurrency: currency,
            finalAmount,
            finalAmountCurrency: currency
        }

        // console.log({ amountWithFeesData });

        return amountWithFeesData;
    } catch (error) {
        logger.error(
            `[calculateAmountWithFees]
             error: ${error}`
        );

        console.error("Error when calculating amount with fees", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when calculating amount with fees" + error);
    }
}

/**
 * Calculates the final amount after converting to the default currency (EUR) and applying country-specific fees.
 * 
 * @param {number} amount - The base amount to be converted and processed (e.g., 100).
 * @param {string} currency - The currency code of the base amount (e.g., "USD", "EUR").
 * @param {string} countryIsoCode - The ISO country code (e.g., "US", "FR").
 * @returns An object containing details of the conversion, fees, and final amount.
*/
// TODO: Move in another file ? Useful ? Maybe do calculations first, then convert (another function ?). Is this still useful ?
export const calculateFinalAmount = async (amount, currency, countryIsoCode) => {
    try {
        const convertedAmountCurrency = await convertAmountCurrency(amount, currency, "EUR");

        const amountWithFees = await calculateAmountWithFees(convertedAmountCurrency.convertedAmount, convertedAmountCurrency.targetCurrency, countryIsoCode)

        const finalAmountData = {
            baseAmount: amount,
            baseCurrency: currency,

            convertedAmount: convertedAmountCurrency.convertedAmount,
            targetCurrency: convertedAmountCurrency.targetCurrency,

            exchangeRate: convertedAmountCurrency.exchangeRate,
            exchangeRateLastUpdate: convertedAmountCurrency.exchangeRateLastUpdate,

            percentageFee: amountWithFees.percentageFee,
            extraFee: amountWithFees.extraFee,
            totalFee: amountWithFees.totalFee,
            feeCurrency: amountWithFees.feeCurrency,

            finalAmount: amountWithFees.finalAmount,
            finalAmountCurrency: amountWithFees.finalAmountCurrency
        }

        console.log(finalAmountData);

        return finalAmountData;

    } catch (error) {
        logger.error(
            `[calculateFinalAmount]
             error: ${error}`
        );

        console.error("Error when calculating final amount", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when calculating final amount" + error);
    }
} 