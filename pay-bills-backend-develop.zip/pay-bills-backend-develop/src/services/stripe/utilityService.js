// @ts-check

import Stripe from "stripe";
import { reloadlyUtilityService } from "../reloadly/utilityService.js";
import logger from "../../utils/logger.js";
import { convertAmountCurrency } from "../currencies/converter.js";
import { STRIPE_TRANSACTION_CURRENCY } from "../../constants/stripeConstants.js";

export const StripeUtilityService = {
  billerTypes: {
    ELECTRICITY_BILL_PAYMENT: "Electricity",
    WATER_BILL_PAYMENT: "Water",
    TV_BILL_PAYMENT: "TV",
    INTERNET_BILL_PAYMENT: "Internet",
  },

  CreateCheckoutForSingleUtility: async (
    // <- TODO rename this to CreateCheckoutForSingleItem
    name,
    simpleType,
    billerLocalCurrency,
    billerFeeInLocalCurrency,
    amount,
    orderID,
    email
  ) => {
    try {
      // Converting amount into stripe transaction currency (arbitrary)
      const convertedFeeData = await convertAmountCurrency(billerFeeInLocalCurrency, billerLocalCurrency, STRIPE_TRANSACTION_CURRENCY);

      console.log({ convertedFeeData });

      const convertedAmountData = await convertAmountCurrency(amount, billerLocalCurrency, STRIPE_TRANSACTION_CURRENCY);

      console.log({ convertedAmountData });

      const stripePrivateKey = process.env.STRIPE_PRIVATE_KEY;

      if (!stripePrivateKey) {
        throw new Error("'STRIPE_PRIVATE_KEY' not found. Check the env variables")
      }

      const stripe = new Stripe(stripePrivateKey);

      const stripeSession = await stripe.checkout.sessions.create({
        payment_method_types: [
          "card",
          // "acss_debit",
          // "affirm",
          // "afterpay_clearpay",
          // "alipay",
          // "amazon_pay",
          // "au_becs_debit",
          // "bacs_debit",
          // "bancontact",
          // "blik",
          // "boleto",
          // "cashapp",
          // "customer_balance",
          // "eps",
          // "fpx",
          // "giropay",
          // "grabpay",
          // "ideal",
          // "klarna",
          // "konbini",
          // "link",
          // "mobilepay",
          // "multibanco",
          // "oxxo",
          // "p24",
          // "paynow",
          // "paypal",
          // "pix",
          // "promptpay",
          // "revolut_pay",
          // "sepa_debit",
          // "sofort",
          // "swish",
          // "twint",
          // "us_bank_account",
          // "wechat_pay",
          // "zip",
        ],
        mode: "payment",
        customer_email: email,
        success_url: `${process.env.FRONTEND_URL}/payments/success`,
        cancel_url: `${process.env.FRONTEND_URL}/payments/cancel`,
        line_items: [
          {
            price_data: {
              currency: STRIPE_TRANSACTION_CURRENCY,
              product_data: {
                name: `${name} - ${simpleType}`,
                //metadata: `${name} - ${simpleType}`,
              },
              unit_amount: Math.ceil((convertedFeeData.convertedAmount + convertedAmountData.convertedAmount) * 100), // multiplied by 100, because amount has to be expressed in the smallest unit currency (in case of EUR, it is the cents)
            },
            quantity: 1,
          },
        ],
        metadata: {
          order_id: orderID,
        },
        payment_intent_data: {
          metadata: {
            order_id: orderID,
          },
        },
      });
      return stripeSession;
    } catch (e) {
      logger.error(
        `[CreateCheckoutForSingleUtility] prams: ${JSON.stringify({
          name,
          simpleType,
          billerLocalCurrency,
          billerFeeInLocalCurrency,
          amount,
          orderID,
          email,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("error sending payment info to stype " + e);
    }
  },
};
