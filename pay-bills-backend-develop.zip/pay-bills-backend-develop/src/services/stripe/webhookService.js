import { ordersDatabaseService } from "../database/orders.js";
import { ProcessReloadlyOrder } from "../reloadly/processOrder.js";

import { emailOrderSummary } from "../email/emailOrderSummary.js"
import { updateOrderSummaryStatusByOrderId } from "../database/orderSummary.js"
import { createTransaction } from "../database/transaction.js"

export const StripeWebhookService = {
  processEvent: async (event) => {
    switch (event.type) {
      case "payment_intent.created":
        const pendingOrderDetails = event.data.object;

        const pendingOrderDetailsOrderId = parseInt(
          pendingOrderDetails.metadata.order_id
        );
        const orderStatus = ordersDatabaseService.GetOrderStatus(
          pendingOrderDetailsOrderId
        );
        if (orderStatus === "Sent to checkout") {
          //Only updata status to processing if current order status is sent to checkout
          //We do this because in somecases the order can complete before processing finnishes if this is the case then the completed status would be overwriten by pending
          //this is to prevent that
          ordersDatabaseService.UpdateOrderStatus(
            pendingOrderDetailsOrderId,
            "Processing"
          );

          updateOrderSummaryStatusByOrderId(pendingOrderDetailsOrderId, "PENDING")
        }

        break;

      case "checkout.session.completed":
        const completedOrderDetails = event.data.object;

        const completedOrderDetailsOrderId = parseInt(
          completedOrderDetails.metadata.order_id
        );
        ordersDatabaseService.UpdateOrderStatus(
          completedOrderDetailsOrderId,
          "Payment Recived"
        );

        updateOrderSummaryStatusByOrderId(completedOrderDetailsOrderId, "PAID")

        await ProcessReloadlyOrder(completedOrderDetailsOrderId);

        emailOrderSummary(completedOrderDetailsOrderId);

        createTransaction({
          orderId: completedOrderDetailsOrderId,
          amountPaid: completedOrderDetails.amount_total,
          currencyCode: completedOrderDetails.currency,
          stripeTxNumber: completedOrderDetails.payment_intent,
        });

        break;

      case "checkout.session.async_payment_succeeded":
        const AsyncCompletedOrderDetails = event.data.object;

        const AsyncCompletedOrderDetailsOrderId = parseInt(
          AsyncCompletedOrderDetails.metadata.order_id
        );
        ordersDatabaseService.UpdateOrderStatus(
          AsyncCompletedOrderDetailsOrderId,
          "Payment Recived"
        );

        updateOrderSummaryStatusByOrderId(AsyncCompletedOrderDetailsOrderId, "PAID")

        await ProcessReloadlyOrder(AsyncCompletedOrderDetailsOrderId);

        emailOrderSummary(AsyncCompletedOrderDetailsOrderId);

        createTransaction({
          orderId: completedOrderDetailsOrderId,
          amountPaid: completedOrderDetails.amount_total,
          currencyCode: completedOrderDetails.currency,
          stripeTxNumber: completedOrderDetails.payment_intent,
        });

        break;

      case "payment_intent.payment_failed":
        const failedOrderDetails = event.data.object;

        const failedOrderDetailsOrderId = parseInt(
          failedOrderDetails.metadata.order_id
        );
        ordersDatabaseService.UpdateOrderStatus(
          failedOrderDetailsOrderId,
          "Payment Failed"
        );

        updateOrderSummaryStatusByOrderId(failedOrderDetailsOrderId, "FAILED")

        break;

      case "checkout.session.async_payment_failed":
        const asyncFailedOrderDetails = event.data.object;

        const asyncFailedOrderDetailsOrderId = parseInt(
          asyncFailedOrderDetails.metadata.order_id
        );
        ordersDatabaseService.UpdateOrderStatus(
          asyncFailedOrderDetailsOrderId,
          "Payment Failed"
        );

        updateOrderSummaryStatusByOrderId(asyncFailedOrderDetailsOrderId, "FAILED")

        break;

      case "checkout.session.expired":
        const expiredOrderDetails = event.data.object;

        const expiredOrderDetailsOrderId = parseInt(
          expiredOrderDetails.metadata.order_id
        );
        ordersDatabaseService.UpdateOrderStatus(
          expiredOrderDetailsOrderId,
          "Checkout Expired"
        );

        updateOrderSummaryStatusByOrderId(expiredOrderDetailsOrderId, "CANCELLED")

        break;

      // ... handle other event types - I dont think this is needede
      // default:
      //   console.log(`Unhandled event type ${event.type}`);
    }
  },
};

//TODO add try & catches to all cases
//TODO call reloadly API and process the paymnet on reloadlys end once stripe payment has cleared - DONE FOR UTILITY PAYMENTS, airtime and giftcard still needs work

//----Done-----
// use payment_intent.created to set payment status to pending
// use checkout.session.completed & checkout.session.async_payment_succeeded to proceed to reloadly api as this means the payment has been taken sucsessfully
// use payment_intent.payment_failed & checkout.session.async_payment_failed to set status as payment failed
// use checkout.session.expired for expired sessions
