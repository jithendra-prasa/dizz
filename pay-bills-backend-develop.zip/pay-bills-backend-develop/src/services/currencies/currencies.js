import { getData } from "../../utils/fetch.js"
import logger from "../../utils/logger.js";

const exchangeRatesEndpoint = process.env.OXR_API;
const oxrAppId = process.env.OXR_APP_ID;

export const getExchangeRatesFromAPI = async () => {
    try {
        // TODO: check response format with zod or joi
        const data = await getData(exchangeRatesEndpoint + "?app_id=" + oxrAppId);

        // console.log(data);

        return data;
    } catch (error) {
        // TODO: Retry in case of failure

        logger.error(
            `[getCurrenciesExchangeRates]
             error: ${error}`
        );

        console.error(error);

        // Handle this in upper levels so the app does not crash
        throw new Error("Error when getting currency exchange rates from external API" + error);
    }
}

// {
//     disclaimer: "https://openexchangerates.org/terms/",
//     license: "https://openexchangerates.org/license/",
//     timestamp: 1449877801,
//     base: "USD",
//     rates: {
//         AED: 3.672538,
//         AFN: 66.809999,
//         ALL: 125.716501,
//         AMD: 484.902502,
//         ANG: 1.788575,
//         AOA: 135.295998,
//         ARS: 9.750101,
//         AUD: 1.390866,
//     }
// }