// @ts-check

import Decimal from "decimal.js";
import logger from "../../utils/logger.js";
import { getExchangeRateByCurrrency } from "../database/currencyExchangeRates.js"
import { DEFAULT_DECIMAL_PLACES } from "../../constants/decimalConstants.js";

// TODO: Document so typing is clear
/**
 * Convert an amount `from` a specified currency `to` another currency
 * 
 * @param {number} amount The amount to convert
 * @param {string} currencyFrom The base currency (3-character ISO code) to convert from
 * @param {string} currencyTo The target currency (3-character ISO code) to convert to
 * @returns 
 */
export const convertAmountCurrency = async (amount, currencyFrom, currencyTo) => {
    try {
        // const data = await getExchangeRateByCurrrency(currencyFrom);

        const data = await calculateExchangeRateFromTo(currencyFrom, currencyTo)

        const exchangeRate = data.exchangeRate;

        // const convertedAmount = parseFloat(
        //     (amount * exchangeRate)
        //         .toFixed(2)
        // );

        const amountDecimal = new Decimal(amount);
        const exchangeRateDecimal = new Decimal(exchangeRate);

        // * => (amount * exchangeRate)
        const convertedAmountDecimal = amountDecimal.times(exchangeRateDecimal);

        const convertedAmount = convertedAmountDecimal.toDecimalPlaces(DEFAULT_DECIMAL_PLACES).toNumber();

        return {
            baseAmount: amount,
            baseCurrency: currencyFrom,
            convertedAmount,
            targetCurrency: currencyTo,
            exchangeRate,
            exchangeRateLastUpdate: data.exchangeRateLastUpdate
        }
    } catch (error) {
        logger.error(
            `[convertAmountCurrency]
             error: ${error}`
        );

        console.error("Error when converting currency", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when converting currency" + error);
    }
}

/**
 * Returns exchange rate `from` a specified currency `to` another.
 * 
 * Proceeds by getting both currencies exchange rates (to the default currency (USD)) and then deducing the exchange rate (between `currencyFrom` and `currencyTo`)
 * @param {string} currencyFrom The base currency (3-character ISO code) to convert from
 * @param {string} currencyTo The target currency (3-character ISO code) to convert to
 */
// TODO: make "currencyTo" defaults to USD ?
export const calculateExchangeRateFromTo = async (currencyFrom, currencyTo) => {
    try {
        const currencyFromExchangeRate = await getExchangeRateByCurrrency(currencyFrom);
        const currencyToExchangeRate = await getExchangeRateByCurrrency(currencyTo);

        // const exchangeRate = (1 / currencyFromExchangeRate.exchangeRate) / (1 / currencyToExchangeRate.exchangeRate);

        const oneDecimal = new Decimal(1);
        const currencyFromExchangeRateDecimal = new Decimal(currencyFromExchangeRate.exchangeRate.toString());
        const currencyToExchangeRateDecimal = new Decimal(currencyToExchangeRate.exchangeRate.toString());

        // * => (1 / currencyFromExchangeRate.exchangeRate) / (1 / currencyToExchangeRate.exchangeRate)
        const exchangeRateDecimal = oneDecimal.dividedBy(currencyFromExchangeRateDecimal)
            .dividedBy(oneDecimal.dividedBy(currencyToExchangeRateDecimal));

        const exchangeRate = exchangeRateDecimal.toNumber();
        // console.log(exchangeRate
        //     // .toString()
        // );

        return {
            currencyFrom,
            currencyTo,
            exchangeRate,
            exchangeRateLastUpdate: currencyFromExchangeRate.updatedAt
        }
    } catch (error) {
        logger.error(
            `[calculateExchangeRateFromTo]
             error: ${error}`
        );

        console.error("Error when calculating exchange rate", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when calculating exchange rate" + error);
    }
}