
import { prisma } from "../../server.js";

export const getOrderSummaryByOrderId = async (orderId) => {
    return await prisma.orderSummary.findUnique({
        where: { orderId: orderId },
    });
}

/**
 * The possible statuses are : "CHECKOUT", "PENDING", "PAID", "CANCELLED", "FAILED"
 */
export const updateOrderSummaryStatusByOrderId = async (orderId, status) => {
    return await prisma.orderSummary.update({
        where: { orderId },
        data: { status }
    });
}

export const updateOrderSummaryRedeemCode = async (orderId, giftCardNumber, giftCardPinCode) => {
    return await prisma.orderSummary.update({
        where: { orderId },
        data: { giftCardNumber, giftCardPinCode }
    });
}

// TODO: try...catch