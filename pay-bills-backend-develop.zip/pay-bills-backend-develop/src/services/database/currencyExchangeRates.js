// @ts-check

import { prisma } from "../../server.js";
import { compareDates } from "../../utils/compareDates.js";
import logger from "../../utils/logger.js";
import { getExchangeRatesFromAPI } from "../currencies/currencies.js"

export const insertExchangeRatesIntoDB = async () => {
    try {
        const seedName = 'exchange-rates-seed';

        // Check if the seed has already been run today
        // To avoid unecessary calls to the API
        const existingSeed = await prisma.seed.findUnique({
            where: { name: seedName },
        });

        if (existingSeed && existingSeed.updatedAt) {
            const dateCompare = compareDates(existingSeed.updatedAt, new Date())

            // Last update was today
            if (dateCompare === 0) {
                console.log('Currency exchange rates are up-to-date.');
                return;
            }
        }
        // * No exchange rate in DB or exchange rates are outdated ->

        const data = await getExchangeRatesFromAPI();

        const baseCurrency = data.base; // default is : USD
        const rates = data.rates;

        let currencyExchangeRates = [];

        // Populating currency exchange rates, to be in ideal DB format
        for (const [currencyCode, rate] of Object.entries(rates)) {
            currencyExchangeRates.push({
                baseCurrency: baseCurrency,
                targetCurrency: currencyCode,
                exchangeRate: rate,
            });
        }

        // console.log(currencyExchangeRates, new Date().toISOString());

        // Inserting currency exchange rates into DB
        await prisma.$transaction([
            // Delete all rows
            prisma.currencyExchangeRates.deleteMany(),

            // Reset the auto-increment value to 1
            prisma.$executeRaw`ALTER TABLE currency_exchange_rates AUTO_INCREMENT = 1`,

            // Insert new data
            prisma.currencyExchangeRates.createMany({ data: currencyExchangeRates, skipDuplicates: true })
        ]);


        // Mark the seed as applied
        await prisma.seed.upsert({
            where: { name: seedName },
            update: { name: seedName },
            create: { name: seedName },
        });

        console.log('Currency exchange rates updated.', new Date());

    } catch (error) {
        logger.error(
            `[insertExchangeRatesIntoDB]
             error: ${error}`
        );

        console.error("Error when inserting currency exchange rates into DB", error);

        // Handle this in upper levels so the app does not crash
        // throw new Error("Error when inserting currency exchange rates into DB" + error);
    }
}

export const getCurrencyExchangeRates = async () => {
    try {
        const data = await prisma.currencyExchangeRates.findMany();

        return data;
    } catch (error) {
        logger.error(
            `[getCurrencyExchangeRates]
             error: ${error}`
        );

        console.error("Error when getting currency exchange rates from DB", error);

        // Handle this in upper levels so the app does not crash
        // throw new Error("Error when getting currency exchange rates from DB" + error);
    }
};

/**
 * Function to get exchange rate from `USD` to a specified `currency`
 * 
 * @param {string} currency currency 3-character ISO code
 */
export const getExchangeRateByCurrrency = async (currency) => {
    try {
        const data = await prisma.currencyExchangeRates.findFirst({
            where: {
                targetCurrency: {
                    equals: currency
                }
            }
        });

        if (!data) {
            throw new Error("No exchange rate found for that currency");
        }

        return data;
    } catch (error) {
        logger.error(
            `[getExchangeRateByCurrrency]
             error: ${error}`
        );

        console.error("Error when getting exchange rates by currency", error);

        // Handle this in upper levels so the app does not crash
        throw new Error("Error when getting exchange rates by currency" + error);
    }
};



// {
//     disclaimer: "https://openexchangerates.org/terms/",
//     license: "https://openexchangerates.org/license/",
//     timestamp: 1449877801,
//     base: "USD",
//     rates: {
//         AED: 3.672538,
//         AFN: 66.809999,
//         ALL: 125.716501,
//         AMD: 484.902502,
//         ANG: 1.788575,
//         AOA: 135.295998,
//         ARS: 9.750101,
//         AUD: 1.390866,
//     }
// }