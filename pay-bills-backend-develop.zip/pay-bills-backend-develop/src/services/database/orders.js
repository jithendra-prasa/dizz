import { PrismaClient } from "@prisma/client";
import logger from "../../utils/logger.js";
import { prisma } from "../../server.js";
import { z } from "zod";

export const ordersDatabaseService = {
  CreateNewOrder: async (userID, service, items, currency, total) => {
    const prisma = new PrismaClient();
    try {
      const newOrder = await prisma.order.create({
        data: {
          userId: userID,
          service,
          items,
          currency,
          total,
          status: "Sent to checkout",
        },
      });

      return newOrder;
    } catch (e) {
      logger.error(
        `[ordersDatabaseService.CreateNewOrder] prams: ${JSON.stringify({
          userID,
          service,
          items,
          currency,
          total,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error when writing order to the DB " + e);
    }
  },

  UpdateOrderStatus: async (orderId, newStatus) => {
    const prisma = new PrismaClient();
    try {
      const updatedOrder = await prisma.order.update({
        where: {
          id: orderId,
        },
        data: {
          status: newStatus,
        },
      });
      return updatedOrder;
    } catch (e) {
      logger.error(
        `[ordersDatabaseService.UpdateOrderStatus] prams: ${JSON.stringify({
          orderId,
          newStatus,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when updating orderID " + orderId + " in the database " + e
      );
    }
  },

  GetOrderDetails: async (orderId) => {
    const prisma = new PrismaClient();

    try {
      const orderDetails = await prisma.order.findUnique({
        where: {
          id: orderId,
        },
        include: {
          user: false,
        },
      });

      return orderDetails;
    } catch (e) {
      logger.error(
        `[ordersDatabaseService.GetOrderDetails] prams: ${JSON.stringify({
          orderId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when getting the order details for orderid " + orderId + " " + e
      );
    }
  },

  GetOrderStatus: async (orderId) => {
    const prisma = new PrismaClient();

    try {
      const order = await prisma.order.findUnique({
        where: {
          id: orderId,
        },
        include: {
          user: false,
        },
      });

      const orderStatus = order.status;
      return orderStatus;
    } catch (e) {
      logger.error(
        `[ordersDatabaseService.GetOrderStatus] prams: ${JSON.stringify({
          orderId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when getting the order status for orderid " + orderId + " " + e
      );
    }
  },

  UpdateVendorFields: async (
    orderId,
    vendorOrderId,
    vendorOrderStatus,
    VendorFullResponce
  ) => {
    const prisma = new PrismaClient();

    // Build the data object conditionally
    const data = {
      ...(vendorOrderId !== null && { venderOrderId: vendorOrderId }),
      ...(vendorOrderStatus !== null && {
        venderOrderStatus: vendorOrderStatus,
      }),
      ...(VendorFullResponce !== null && {
        VenderFullResponce: VendorFullResponce,
      }),
    };

    // Check if data object is not empty
    if (Object.keys(data).length === 0) {
      throw new Error("No valid fields to update for orderid " + orderId);
    }

    try {
      const order = await prisma.order.update({
        where: {
          id: orderId,
        },
        data: data,
      });

      return order;
    } catch (e) {
      logger.error(
        `[ordersDatabaseService.UpdateVendorFields] prams: ${JSON.stringify({
          orderId,
          vendorOrderId,
          vendorOrderStatus,
          VendorFullResponce,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error(
        "Error when updating the vender info for orderid " + orderId + " " + e
      );
    }
  },

  /**
  * Updates the PawaPay Deposit ID in the order summary.
  * 
  * @param {number} orderId 
  * @param {string} pawaPayDepositId 
  */
  updateOrderPawapayDepositId: async (/** @type {number} */ orderId, /** @type {string} */ pawaPayDepositId) => {
    try {
      // Validate pawaPayDepositId
      const parsedPawaPayDepositId = PawaPayDepositIdSchema.parse(pawaPayDepositId);

      return await prisma.order.update({
        where: { id: orderId },
        data: { pawaPayDepositId: parsedPawaPayDepositId }
      });
    } catch (e) {
      console.error("Error updating PawaPay deposit ID:", e);

      logger.error(
        `[ordersDatabaseService.updateOrderPawapayDepositId] params: ${JSON.stringify({
          orderId,
          pawaPayDepositId
        })} error: ${JSON.stringify(e)}`
      );

      throw new Error(`Error when updating PawaPay deposit ID for order ${orderId}: ${e}`);
    }
  }
};

/**
 * Zod schema to validate PawaPay Deposit ID
 * 
 * @type {z.ZodString}
 */
const PawaPayDepositIdSchema = z.string()
  .nonempty({ message: "PawaPay Deposit ID is required" })
  .uuid({ message: "Invalid PawaPay Deposit ID. Must be a UUIDv4" });