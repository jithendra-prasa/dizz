// @ts-check

import { prisma } from "../../server.js"
import logger from "../../utils/logger.js";

/**
 * Function to get currency symbol
 * 
 * @param {string} currencyCode currency 3-character ISO code. Preferrably in uppercase
 * 
 */
export const getCurrencySymbol = async (currencyCode) => {
    try {
        if (!currencyCode) {
            throw new Error("'currencyCode' is missing. Please, provide it.")
        }

        const data = await prisma.currency.findFirst({
            where: { name: currencyCode },
        })

        if (!data) {
            throw new Error("No symbol found for that currency. Make sure the currency ISO code is correct");
        }

        console.log(data);

        return {
            currencyCode: data.name,
            currencySymbol: data.symbol
        };
    } catch (error) {
        logger.error(
            `[getCurrencySymbol]
             error: ${error}`
        );

        console.error("Error when getting currency symbol", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when getting currency symbol" + error);
    }
}