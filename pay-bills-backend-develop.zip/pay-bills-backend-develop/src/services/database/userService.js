import { prisma } from "../../server.js";
import logger from "../../utils/logger.js";

export const userService = {
  GetUser: async (userId) => {
    try {
      const user = await prisma.user.findUnique({
        where: {
          id: userId,
        },
      });
      return user;
    } catch (e) {
      logger.error(
        `[userService.GetUser] prams: ${JSON.stringify({
          userId,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error getting user by ID: " + e);
    }
  },

  getUserByEmail: async (email) => {
    try {
      const user = await prisma.user.findUnique({
        where: {
          email,
        },
      });
      return user;
    } catch (e) {
      logger.error(
        `[userService.getUserByEmail] prams: ${JSON.stringify({
          email,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error getting user by Email: " + e);
    }
  },

  createNewUser: async (firstName, surname, email, phoneNumber, password) => {
    try {
      const user = await prisma.user.create({
        data: {
          name: `${firstName} ${surname}`,
          email,
          phoneNumber,
          password, //needs hashed/salted
          isGuest: false,
        },
      });
      return user;
    } catch (e) {
      logger.error(
        `[userService.createNewUser] prams: ${JSON.stringify({
          firstName,
          surname,
          email,
          phoneNumber,
          password,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error creating new guest user" + e);
    }
  },

  createGuestUser: async (firstName, surname, email) => {
    try {
      const user = await prisma.user.create({
        data: {
          name: `${firstName} ${surname}`,
          email,
          phoneNumber: "",
          password: "",
          isGuest: true,
        },
      });
      return user;
    } catch (e) {
      logger.error(
        `[userService.createGuestUser] prams: ${JSON.stringify({
          firstName,
          surname,
          email,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error creating new guest user" + e);
    }
  },

  UpdateFromGuestToFullAccount: async (id, phoneNumber, password) => {
    try {
      const user = await prisma.user.update({
        where: {
          id,
        },

        data: {
          password, //needs hashing
          phoneNumber,
          isGuest: false,
        },
      });
      return user;
    } catch (e) {
      logger.error(
        `[userService.UpdateFromGuestToFullAccount] prams: ${JSON.stringify({
          id,
          phoneNumber,
          password,
        })} error: ${JSON.stringify(e)}`
      );
      throw new Error("Error updating user" + e);
    }
  },
};
