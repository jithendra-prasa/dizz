import { prisma } from "../../server.js";

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { MomoProvidersSchema } from "../../models/momoProvidersSchema.js";

// ES module workaround for __dirname. 
// TODO: Check if this workaround is necessary
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Util function to insert "momoProviders.json" data into the corresponding tables
 */
export const insertMomoProvidersIntoDB = async () => {
    try {
        const seedName = 'momo-providers-seed';

        // Check if the seed has already been run
        const existingSeed = await prisma.seed.findUnique({
            where: { name: seedName },
        });

        if (existingSeed) {
            console.log('Mobile money providers seed already applied.');
            return;
        }

        // TODO: Implement logic for re-seed (update) and reset (delete all and re-insert)

        // Load JSON data
        const filePath = path.join(__dirname, 'momo_providers.json');

        const momoProviders = JSON.parse(await fs.readFile(filePath, 'utf-8'));

        // Validate the data against the schema
        const parsedMomoProviders = MomoProvidersSchema.parse(momoProviders);
        console.log('Parsed mobile money providers data:', parsedMomoProviders);

        // Insert the data into the database
        for (const momoProvider of parsedMomoProviders) {
            await prisma.momoProvider.create({
                data: {
                    name: momoProvider.name,
                    status: momoProvider.status,
                    supportedCountries: {
                        create: momoProvider.countries.map((country) => ({
                            countryIso2: country.countryIso2,
                            countryIso3: country.countryIso3,
                            // countryInfo: {
                            //     connect: {
                            //         isoCode: country.countryIso2
                            //     }
                            // },
                            supportedOperators: {
                                create: country.operators.map((operator) => ({
                                    name: operator.name,
                                    momoName: operator.momoName,
                                    percentageFee: operator.percentageFee,
                                    status: operator.status,
                                })),
                            }
                        })),
                    },

                },
            });
        }

        // Mark the seed as applied
        await prisma.seed.create({
            data: { name: seedName },
        });

        console.log('Mobile money providers data inserted successfully');
    } catch (error) {
        console.error('Error inserting mobile money providers data:', error);
    }
};
