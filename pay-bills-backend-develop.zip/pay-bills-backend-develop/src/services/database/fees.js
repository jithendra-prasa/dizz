import { DEFAULT_PERCENTAGE_FEE, EXTRA_FEE, EXTRA_FEE_CURRENCY } from "../../constants/feesConstants.js";
import { prisma } from "../../server.js"
import logger from "../../utils/logger.js";

const defaultFees = {
    percentageFee: DEFAULT_PERCENTAGE_FEE,
    extraFee: EXTRA_FEE,
    extraFeeCurrency: EXTRA_FEE_CURRENCY,
}

/**
 * Function to get country-specific fees
 * 
 * @param {string} isoCode country 2-character ISO code. Preferrably in uppercase
 * 
 */
export const getFeesByCountry = async (isoCode) => {
    try {
        if (!isoCode) {
            throw new Error("'isoCode' is missing. Please, provide it.")
        }
        
        const data = await prisma.country.findUnique({
            where: { isoCode: isoCode },
            select: {
                name: true,
                fees: {
                    select: {
                        percentageFee: true,
                        extraFee: true,
                        extraFeeCurrency: true,
                    }
                }
            },
        })

        if (!data) {
            throw new Error("No fees found for that country. Make sure the country ISO code is correct");
        }

        const countryFees = {
            countryName: data.name,
            fees: data.fees ?? defaultFees,
        }

        // console.log(countryFees);

        return countryFees;
    } catch (error) {
        logger.error(
            `[getFeesByCountry]
             error: ${error}`
        );

        console.error("Error when getting fees by country", error);

        // * Handle this in upper levels so the app does not crash
        throw new Error("Error when getting fees by country" + error);
    }
}