
import { prisma } from "../../server.js";

export const retrieveLocationDataQuery = async (isoCode) => {
    return await prisma.country.findUnique({
        where: { isoCode: isoCode },
        select: {
            name: true,
            continents: {
                select: {
                    name: true,
                },
            }
        },
        // include: {
        //     // currencies: true,
        //     // callingCodes: true,
        //     continents: true,
        // },
    });
}