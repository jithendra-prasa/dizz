import { prisma } from "../../server.js";

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

// ES module workaround for __dirname. 
// TODO: Check if this workaround is necessary
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Util function to insert "countries.json" data into the corresponding tables
 */
export const insertCountriesIntoDB = async () => {
    try {
        const seedName = 'countries-seed';

        // Check if the seed has already been run
        const existingSeed = await prisma.seed.findUnique({
            where: { name: seedName },
        });

        if (existingSeed) {
            console.log('Countries seed already applied.');
            return;
        }

        // Load JSON data
        const filePath = path.join(__dirname, 'countries.json');
        const countries = JSON.parse(await fs.readFile(filePath, 'utf-8'));

        // Insert the data into the database
        for (const country of countries) {
            await prisma.country.create({
                data: {
                    name: country.name,
                    isoCode: country.isoCode,
                    currencies: {
                        create: country.currencies.map((currency) => ({
                            name: currency.name,
                            fullName: currency.fullName,
                            symbol: currency.symbol,
                        })),
                    },
                    callingCodes: {
                        create: country.callingCodes.map((code) => ({
                            code,
                        })),
                    },
                    continents: {
                        create: country.continents.map((continent) => ({
                            name: continent,
                        })),
                    },
                },
            });
        }

        // Mark the seed as applied
        await prisma.seed.create({
            data: { name: seedName },
        });

        console.log('Countries data inserted successfully');
    } catch (error) {
        console.error('Error inserting countries data:', error);
    }
};
