import { prisma } from "../../server.js";
import { getOrderSummaryByOrderId } from "../database/orderSummary.js"
import logger from "../../utils/logger.js";


export const createTransaction = async (
    {
        // orderSummaryId,
        // userId,
        orderId,
        amountPaid,
        currencyCode,
        stripeTxNumber,
        cryptoTxNumber,
        mobileMoneyTxNumber
    }
) => {
    try {

        const orderSummary = await getOrderSummaryByOrderId(orderId);

        const orderSummaryId = orderSummary.id;
        const userId = orderSummary.userId;

        const data = {
            orderSummaryId,
            userId,
            amountPaid,
            currencyCode,
            stripeTxNumber,
            cryptoTxNumber,
            mobileMoneyTxNumber
        };

        const newTransaction = await prisma.transaction.create({
            data,
        });

        return newTransaction;
    } catch (e) {
        logger.error(
            `[createTransaction] params: ${JSON.stringify({
                // orderSummaryId,
                // userId,
                orderId,
                amountPaid,
                currencyCode,
                stripeTxNumber,
                cryptoTxNumber,
                mobileMoneyTxNumber
            })} 
             error: ${JSON.stringify(e)}`
        );
        
        throw new Error("Error when writing transaction to the DB " + e);
    }
}