// @ts-check

import { z } from "zod";
import { updateOrderSummaryStatusByOrderId } from "../database/orderSummary.js";
import { ProcessReloadlyOrder } from "../reloadly/processOrder.js";
import { emailOrderSummary } from "../email/emailOrderSummary.js";
import { createTransaction } from "../database/transaction.js";
import logger from "../../utils/logger.js";
import { ordersDatabaseService } from "../database/orders.js";
import { PawaPayDepositSchema } from "../../models/pawaPaySchema.js";
import Decimal from "decimal.js";

/**
 * Processes PawaPay webhook events
 * 
 * Uses payment status (COMPLETED, FAILED) to update order status in DB and also trigger Reloadly order
 * 
 * @param {z.infer<typeof PawaPayDepositSchema>} eventData 
 */
export const processPawaPayDepositEvent = async (/** @type {z.infer<typeof PawaPayDepositSchema>} */ eventData) => {
    try {
        const orderId = eventData.metadata?.orderId;

        if (!orderId) {
            const errorMessage = "PawaPay Webhook event - orderId is null - CANNOT UPDATE ORDER\n"
                + "depositId = " + eventData.depositId;

            logger.error(errorMessage);

            throw new Error(errorMessage)
        }

        switch (eventData.status) {

            case "COMPLETED":

                const completedOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    completedOrderDetailsOrderId,
                    "Payment Recived"
                );

                updateOrderSummaryStatusByOrderId(completedOrderDetailsOrderId, "PAID")

                await ProcessReloadlyOrder(completedOrderDetailsOrderId);

                emailOrderSummary(completedOrderDetailsOrderId);

                createTransaction({
                    orderId: completedOrderDetailsOrderId,
                    amountPaid: new Decimal(eventData.requestedAmount).toNumber(), // number
                    currencyCode: eventData.currency,
                    cryptoTxNumber: null,
                    stripeTxNumber: null,
                    mobileMoneyTxNumber: eventData.depositId,
                });

                logger.info("COMPLETED", orderId);

                break;

            case "FAILED":

                const failedOrderDetailsOrderId = parseInt(
                    orderId
                );

                ordersDatabaseService.UpdateOrderStatus(
                    failedOrderDetailsOrderId,
                    "Payment Failed"
                );

                updateOrderSummaryStatusByOrderId(failedOrderDetailsOrderId, "FAILED")

                logger.info("FAILED", orderId);

                break;
        }
    } catch (error) {
        throw error;
    }
}