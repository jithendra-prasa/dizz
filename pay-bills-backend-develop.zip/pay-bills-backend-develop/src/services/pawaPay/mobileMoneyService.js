// @ts-check

import { z } from "zod";
import { PawaPayPublicKeysSchema, PaymentPageRequestSchema } from "../../models/pawaPaySchema.js";
import { axiosInstance } from "../../utils/axiosInstance.js";
import logger from "../../utils/logger.js";

const mode = process.env.MODE;

const pawaPayUrl = mode === "PROD" ? process.env.PAWAPAY_API_URL : process.env.PAWAPAY_API_URL_SANDBOX;
const pawaPayApiToken = mode === "PROD" ? process.env.PAWAPAY_API_TOKEN : process.env.PAWAPAY_API_TOKEN_SANDBOX;
// TODO: Use a more neutral URL 
const successUrl = process.env.PAYMENT_SUCCESS_URL;

const OmittedPaymentPageRequestSchema = PaymentPageRequestSchema.omit({ returnUrl: true, language: true });

/**
 * Used to generate PawaPay payment page URL
 * 
 * @param {z.infer<typeof PaymentPageRequestSchema>} paymentDetails
 * 
 * @returns {Promise<{redirectUrl: string}>}
 */
export const requestPawaPayPaymentPage = async (/** @type {z.infer<typeof OmittedPaymentPageRequestSchema>} */ paymentDetails) => {
    try {
        const parsedPaymentDetails = PaymentPageRequestSchema.parse({ ...paymentDetails, returnUrl: successUrl });

        // const finalPaymentDetails = {
        //     ...parsedPaymentDetails,
        // }

        console.log("Parsed payment details", parsedPaymentDetails);

        const response = await axiosInstance.post(pawaPayUrl + "/v1/widget/sessions", parsedPaymentDetails, {
            headers: {
                Authorization: `Bearer ${pawaPayApiToken}`,
            }
        });

        console.log("PawaPay payment page response data", response.data);

        return response.data;
    } catch (error) {
        logger.error(
            `[requestPawaPayPaymentPage]
             error: ${error}`
        );

        throw new Error(`Failed to request pawaPay payment page: ${error}`);
    }
}

/**
 * Used to get PawaPay public keys
 */
export const getPawaPayPublicKeys = async () => {
    try {

        const response = await axiosInstance.get(pawaPayUrl + "/public-key/http", {
            headers: {
                Authorization: `Bearer ${pawaPayApiToken}`,
            }
        });

        // console.log("PawaPay public keys", response.data);

        /** @type {z.infer<typeof PawaPayPublicKeysSchema>} */
        const responseData = response.data;

        return responseData;
    } catch (error) {
        logger.error(
            `[getPawaPayPublicKeys]
             error: ${error}`
        );

        throw new Error(`Failed to get pawaPay public keys: ${error}`);
    }
}


