export const AIRTIME = "AIRTIME";
export const GIFT_CARD = "GIFT_CARD";
export const UTILITY = "UTILITY";