/**
 * Arbitrary currency used for all transactions through NOWPayments API
 */
export const NOW_PAYMENTS_TRANSACTION_CURRENCY = "EUR";