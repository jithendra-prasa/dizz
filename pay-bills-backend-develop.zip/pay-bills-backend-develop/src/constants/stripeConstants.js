/**
 * Arbitrary currency used for all transactions through stripe
 */
export const STRIPE_TRANSACTION_CURRENCY = "EUR"