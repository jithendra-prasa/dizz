export const DEFAULT_PERCENTAGE_FEE = 10;
export const EXTRA_FEE = 0;
export const EXTRA_FEE_CURRENCY = "EUR";