export const CARD = "CARD";
export const CRYPTO = "CRYPTO";
export const MOBILE_MONEY = "MOBILE_MONEY";