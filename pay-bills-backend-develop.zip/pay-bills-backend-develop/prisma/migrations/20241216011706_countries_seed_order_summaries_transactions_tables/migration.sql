-- CreateTable
CREATE TABLE `countries` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `isoCode` VARCHAR(191) NOT NULL,

    UNIQUE INDEX `countries_isoCode_key`(`isoCode`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `currencies` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `fullName` VARCHAR(191) NOT NULL,
    `symbol` VARCHAR(191) NOT NULL,
    `countryId` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `calling_codes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `code` VARCHAR(191) NOT NULL,
    `countryId` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `continents` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `countryId` INTEGER NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `seeds` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `seeds_name_key`(`name`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `order_summaries` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `benPhoneNumber` VARCHAR(191) NOT NULL,
    `benFirstname` VARCHAR(191) NOT NULL,
    `benSurname` VARCHAR(191) NOT NULL,
    `benCity` VARCHAR(191) NOT NULL,
    `benCountry` VARCHAR(191) NOT NULL,
    `serviceType` VARCHAR(191) NOT NULL,
    `productType` VARCHAR(191) NOT NULL,
    `serviceProvider` VARCHAR(191) NULL,
    `billReferenceNumber` VARCHAR(191) NULL,
    `utilityBillAccountNumber` VARCHAR(191) NULL,
    `amountToBePaid` DOUBLE NOT NULL,
    `valueInDizzy` VARCHAR(191) NULL,
    `senderCurrencyCode` VARCHAR(191) NOT NULL,
    `senderCurrencySymbol` VARCHAR(191) NULL,
    `senderName` VARCHAR(191) NOT NULL,
    `senderEmail` VARCHAR(191) NOT NULL,
    `senderPhoneNumber` VARCHAR(191) NULL,
    `senderCity` VARCHAR(191) NOT NULL,
    `senderCountry` VARCHAR(191) NOT NULL,
    `paymentRequestDetails` JSON NOT NULL,
    `paymentMethod` ENUM('CARD', 'CRYPTO', 'MOBILE_MONEY') NOT NULL,
    `status` ENUM('PENDING', 'PAID', 'CANCELLED', 'FAILED') NOT NULL DEFAULT 'PENDING',
    `userId` VARCHAR(191) NOT NULL,
    `transactionId` INTEGER NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `order_summaries_transactionId_key`(`transactionId`),
    INDEX `order_summaries_userId_idx`(`userId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `transactions` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `stripeReferenceId` VARCHAR(191) NULL,
    `type_of_service` VARCHAR(191) NOT NULL,
    `service_provider` VARCHAR(255) NULL,
    `beneficiary_first_name` VARCHAR(255) NOT NULL,
    `beneficiary_surname` VARCHAR(255) NOT NULL,
    `beneficiary_city` VARCHAR(255) NOT NULL,
    `beneficiary_country` VARCHAR(255) NOT NULL,
    `amountPaid` DOUBLE NOT NULL,
    `currencyCode` VARCHAR(191) NOT NULL,
    `buyer_first_name` VARCHAR(255) NOT NULL,
    `buyer_surname` VARCHAR(255) NOT NULL,
    `buyer_city` VARCHAR(255) NOT NULL,
    `buyer_country` VARCHAR(255) NOT NULL,
    `transaction_medium` VARCHAR(255) NULL,
    `tx_value_dizzy` DECIMAL(10, 2) NULL,
    `userId` VARCHAR(191) NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
