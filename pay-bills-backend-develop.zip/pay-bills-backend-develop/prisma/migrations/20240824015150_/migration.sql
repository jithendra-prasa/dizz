/*
  Warnings:

  - You are about to alter the column `total` on the `orders` table. The data in that column could be lost. The data in that column will be cast from `Int` to `Double`.

*/
-- AlterTable
ALTER TABLE `orders` MODIFY `total` DOUBLE NOT NULL,
    MODIFY `venderOrderId` VARCHAR(191) NULL;
