/*
  Warnings:

  - A unique constraint covering the columns `[pawaPayDepositId]` on the table `order_summaries` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `pawaPayDepositId` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `order_summaries_pawaPayDepositId_key` ON `order_summaries`(`pawaPayDepositId`);
