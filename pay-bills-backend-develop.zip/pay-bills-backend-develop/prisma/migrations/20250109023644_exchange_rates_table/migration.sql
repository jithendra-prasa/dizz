-- CreateTable
CREATE TABLE `currency_exchange_rates` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `baseCurrency` VARCHAR(191) NOT NULL DEFAULT 'USD',
    `targetCurrency` VARCHAR(191) NOT NULL,
    `exchangeRate` DOUBLE NOT NULL,
    `updatedAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    UNIQUE INDEX `currency_exchange_rates_targetCurrency_key`(`targetCurrency`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
