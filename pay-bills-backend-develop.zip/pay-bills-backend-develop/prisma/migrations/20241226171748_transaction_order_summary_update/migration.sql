/*
  Warnings:

  - You are about to drop the column `transactionId` on the `order_summaries` table. All the data in the column will be lost.
  - You are about to drop the column `beneficiary_city` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `beneficiary_country` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `beneficiary_first_name` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `beneficiary_surname` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `buyer_city` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `buyer_country` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `buyer_first_name` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `buyer_surname` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `service_provider` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `stripeReferenceId` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `transaction_medium` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `tx_value_dizzy` on the `transactions` table. All the data in the column will be lost.
  - You are about to drop the column `type_of_service` on the `transactions` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[mobileMoneyTxNumber]` on the table `transactions` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[cryptoTxNumber]` on the table `transactions` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[stripeTxNumber]` on the table `transactions` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[dizzitupTxNumber]` on the table `transactions` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[orderSummaryId]` on the table `transactions` will be added. If there are existing duplicate values, this will fail.
  - The required column `dizzitupTxNumber` was added to the `transactions` table with a prisma-level default value. This is not possible if the table is not empty. Please add this column as optional, then populate it before making it required.
  - Added the required column `orderSummaryId` to the `transactions` table without a default value. This is not possible if the table is not empty.

*/
-- DropIndex
DROP INDEX `order_summaries_transactionId_key` ON `order_summaries`;

-- AlterTable
ALTER TABLE `order_summaries` DROP COLUMN `transactionId`;

-- AlterTable
ALTER TABLE `transactions` DROP COLUMN `beneficiary_city`,
    DROP COLUMN `beneficiary_country`,
    DROP COLUMN `beneficiary_first_name`,
    DROP COLUMN `beneficiary_surname`,
    DROP COLUMN `buyer_city`,
    DROP COLUMN `buyer_country`,
    DROP COLUMN `buyer_first_name`,
    DROP COLUMN `buyer_surname`,
    DROP COLUMN `service_provider`,
    DROP COLUMN `stripeReferenceId`,
    DROP COLUMN `transaction_medium`,
    DROP COLUMN `tx_value_dizzy`,
    DROP COLUMN `type_of_service`,
    ADD COLUMN `cryptoTxNumber` VARCHAR(191) NULL,
    ADD COLUMN `dizzitupTxNumber` VARCHAR(191) NOT NULL,
    ADD COLUMN `mobileMoneyTxNumber` VARCHAR(191) NULL,
    ADD COLUMN `orderSummaryId` INTEGER NOT NULL,
    ADD COLUMN `stripeTxNumber` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `transactions_mobileMoneyTxNumber_key` ON `transactions`(`mobileMoneyTxNumber`);

-- CreateIndex
CREATE UNIQUE INDEX `transactions_cryptoTxNumber_key` ON `transactions`(`cryptoTxNumber`);

-- CreateIndex
CREATE UNIQUE INDEX `transactions_stripeTxNumber_key` ON `transactions`(`stripeTxNumber`);

-- CreateIndex
CREATE UNIQUE INDEX `transactions_dizzitupTxNumber_key` ON `transactions`(`dizzitupTxNumber`);

-- CreateIndex
CREATE UNIQUE INDEX `transactions_orderSummaryId_key` ON `transactions`(`orderSummaryId`);

-- CreateIndex
CREATE INDEX `transactions_userId_idx` ON `transactions`(`userId`);
