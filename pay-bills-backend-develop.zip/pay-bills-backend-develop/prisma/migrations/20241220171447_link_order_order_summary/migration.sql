/*
  Warnings:

  - A unique constraint covering the columns `[orderId]` on the table `order_summaries` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `orderId` INTEGER NULL;

-- CreateIndex
CREATE UNIQUE INDEX `order_summaries_orderId_key` ON `order_summaries`(`orderId`);
