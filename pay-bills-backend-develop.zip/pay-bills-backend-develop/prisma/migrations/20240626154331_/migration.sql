-- AlterTable
ALTER TABLE `orders` ADD COLUMN `VenderFullResponce` JSON NULL;
