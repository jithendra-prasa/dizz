/*
  Warnings:

  - You are about to alter the column `valueInDizzy` on the `order_summaries` table. The data in that column could be lost. The data in that column will be cast from `VarChar(191)` to `Double`.

*/
-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `baseAmount` DOUBLE NOT NULL DEFAULT 0,
    ADD COLUMN `ourFeeTotal` DOUBLE NOT NULL DEFAULT 0,
    ADD COLUMN `ourPercentageFee` DOUBLE NOT NULL DEFAULT 0,
    ADD COLUMN `serviceFee` DOUBLE NOT NULL DEFAULT 0,
    ADD COLUMN `transactionAmount` DOUBLE NOT NULL DEFAULT 0,
    ADD COLUMN `transactionCurrency` VARCHAR(191) NOT NULL DEFAULT 'EUR',
    ADD COLUMN `transactionCurrencySymbol` VARCHAR(191) NULL,
    DROP COLUMN `valueInDizzy`;
