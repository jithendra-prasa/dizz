-- AlterTable
ALTER TABLE `seeds` ADD COLUMN `updatedAt` DATETIME(3) NULL;
