/*
  Warnings:

  - You are about to drop the column `pawaPayDepositId` on the `order_summaries` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[pawaPayDepositId]` on the table `orders` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX `order_summaries_pawaPayDepositId_key` ON `order_summaries`;

-- AlterTable
ALTER TABLE `order_summaries` DROP COLUMN `pawaPayDepositId`;

-- AlterTable
ALTER TABLE `orders` ADD COLUMN `pawaPayDepositId` VARCHAR(191) NULL;

-- CreateIndex
CREATE UNIQUE INDEX `orders_pawaPayDepositId_key` ON `orders`(`pawaPayDepositId`);
