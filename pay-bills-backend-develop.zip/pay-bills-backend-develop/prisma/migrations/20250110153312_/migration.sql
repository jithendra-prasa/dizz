-- CreateTable
CREATE TABLE `fees` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `percentageFee` DOUBLE NOT NULL DEFAULT 0.2,
    `extraFee` DOUBLE NOT NULL DEFAULT 0,
    `extraFeeCurrency` VARCHAR(191) NOT NULL DEFAULT 'USD',
    `countryId` INTEGER NOT NULL,
    `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `updatedAt` DATETIME(3) NOT NULL,

    UNIQUE INDEX `fees_countryId_key`(`countryId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
