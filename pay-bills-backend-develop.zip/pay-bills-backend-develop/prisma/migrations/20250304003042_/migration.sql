-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `valueInDizzy` DOUBLE NULL;
