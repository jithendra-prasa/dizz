-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `giftCardNumber` VARCHAR(191) NULL,
    ADD COLUMN `giftCardPinCode` VARCHAR(191) NULL,
    ADD COLUMN `giftCardRedeemInstructions` VARCHAR(191) NULL;
