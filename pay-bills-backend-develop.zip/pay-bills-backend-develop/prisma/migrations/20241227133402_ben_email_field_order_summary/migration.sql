-- AlterTable
ALTER TABLE `order_summaries` ADD COLUMN `benEmail` VARCHAR(191) NULL;
