-- AlterTable
ALTER TABLE `order_summaries` MODIFY `giftCardRedeemInstructions` TEXT NULL;
