/*
  Warnings:

  - Made the column `isGuest` on table `users` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE `users` MODIFY `isGuest` BOOLEAN NOT NULL;
