-- AlterTable
ALTER TABLE `users` ADD COLUMN `isOnlyGuest` BOOLEAN NULL;
