/*
  Warnings:

  - You are about to drop the `momo_countries` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `momo_operators` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `momo_providers` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropTable
DROP TABLE `momo_countries`;

-- DropTable
DROP TABLE `momo_operators`;

-- DropTable
DROP TABLE `momo_providers`;
