-- AlterTable
ALTER TABLE `orders` ADD COLUMN `venderOrderId` INTEGER NULL,
    ADD COLUMN `venderOrderStatus` VARCHAR(191) NULL;
