-- AlterTable
ALTER TABLE `momo_operators` MODIFY `percentageFee` DOUBLE NULL;
